# 07 — Jellegzetes hibák és javításuk (LLM/config)

Ez a fájl az LLM-beállításoknál előforduló ismétlődő hibák katalógusa — amit
Péter rendszeresen elront, és ahogyan javítani szoktuk. Hermesnek: ha bármi
modell/config hiba tünete felmerül, először EZT olvasd el — a legtöbb eset
ismert, és itt a pontos javítás.

## A config-fájlok térképe (4 profil!)

| Profil | Config.yaml helye | Megjegyzés |
|---|---|---|
| default | `C:\Users\fekec\AppData\Local\hermes\config.yaml` | A gyökér, a fő profil. HERMES_HOME = AppData\Local\hermes |
| tui | `...\hermes\profiles\tui\config.yaml` | A default ikertestvére (`--clone`) — örökölte a hibákat is! |
| hazi-feladat | `...\hermes\profiles\hazi-feladat\config.yaml` | A default ikertestvére (`--clone`) — örökölte a hibákat is! |
| qwenticoo | NINCS config.yaml | Beépített defaultot használ → F2/menük nem működnek teljesen |

Kulcs-szabály: **ha a defaultban hibát javítasz, nézd meg a másik 3 profilt
is** — a `--clone` profilok örökölték a hibát a létrehozáskor.

---

## H1 — `model.base_url` / `model.api_key` maradvány (a legnagyobb klasszikus)

**Tünet:** `API call failed: Connection error` (3 retry után).

**Ok:** a `config.yaml` `model:` szekciójában ott marad egy korábbi provider
(FLM, Ollama) címe/kulcsa. A `model.base_url` és `model.api_key` **felülírja**
a `model.provider`-hez tartozó provider saját API-ját → minden hívás a régi
(localhost) címre megy, ami nem fut.

**Konkrét eset (2026-08-04):** FLM maradvány volt a configban:
```yaml
model:
  provider: opencode-zen
  default: deepseek-v4-flash-free
  base_url: http://127.0.0.1:52625/v1   # ← FLM daemon, NEM fut
  api_key: ${OLLAMA_API_KEY}            # ← nem ide való
```

**Javítás:**
```bash
cd /c/Users/fekec/AppData/Local/hermes
cp config.yaml config.yaml.bak-<dátum>          # MINDIG backup először
hermes config unset model.api_key
hermes config unset model.base_url
# ellenőrzés:
grep -A5 '^model:' config.yaml
```
A `model.provider` és `model.default` marad — az FLM-nek külön
`providers.flm` szekciója van, oda való a címe.

**Pre-flight szabály:** Connection error esetén MINDIG először:
`grep -A5 '^model:' config.yaml` — és nézd a `base_url`-t!

---

## H2 — `HERMES_DEFAULT_MODEL` a .env-ben felülírja a configot

**Tünet:** a config.yaml `model.default`-je jó, mégis más modell indul.

**Ok:** a `C:\Users\fekec\AppData\Local\hermes\.env`-ben lévő
`HERMES_DEFAULT_MODEL` **felülírja** a configot. A .env erősebb.

**Javítás:** provider/modell váltáskor MINDKETTŐT ellenőrizni:
```bash
grep -n "HERMES_DEFAULT_MODEL" /c/Users/fekec/AppData/Local/hermes/.env
```
Ha ott van és nem kell: törölni a sorból (a .env csak API kulcsokat
tartalmazzon — ez a szabály).

---

## H3 — Vision config elromlott → NÉMA FREEZE

**Tünet:** kép elemzésnél a válasz egyszerűen eltűnik (nincs timeout, nincs
error, csak freeze). A modell nem válaszol.

**Ok:** a `auxiliary.vision` configot felülírták (hermes update, más tool,
véletlen config írás), és olyan modell került bele, ami NEM jó vision-ra:
- `nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free` — content safety
  filter → NÉMA FREEZE. **SOHA nem használható.**
- `meta/llama-3.2-11b-vision-instruct` NVIDIA NIM-en — ~20s timeout.

**Bevált konfig:**
```yaml
auxiliary:
  vision:
    provider: nvidia
    model: nvidia/nemotron-nano-12b-v2-vl
    api_key: ${NVIDIA_API_KEY}
```
(Vagy OpenRouter alternatíva: `google/gemma-4-31b-it:free` + `openrouter`
+ `${OPENROUTER_API_KEY}` — ha az NVIDIA leáll.)

**Pre-flight (MINDEN kép elemzés előtt):**
```bash
hermes config show auxiliary.vision   # modell, provider, api_key mind OK?
```

**Figyelem:** a `vision_analyze` tool **cache-eli a configot session
induláskor** — config váltás után `/new` vagy gateway restart kell, különben
a tool még a régi modellt használja.

**Figyelem 2:** a nemotron-nano-12b-v2-vl **hallucinálhat** képernyő-
részleteket (kitalált fájlneveket üres mappába!) — fájlrendszer-tényeket
mindig `ls`-sel ellenőrizni, a vision-t csak layout-szinten hinni.

---

## H4 — `Max length reached` / OOM (context_length)

**Tünet A:** `Max length reached` — a modell max bemenete kisebb, mint amit a
Hermes küldene.

**Ok:** a Hermes kérése ~40-50k token (nagy rendszerprompt). Sok modell
alapértelmezett max bemenete ~32k → nem fér be.

**Javítás:** a provider/modell `context_length`-ét a modell valós maxára
állítani (a config `model.context_length` vagy `providers.<név>` alatt).
FLM-nél a 131072 (128k) működik; a 262144 NEM fér az NPU-ba (XRT hiba).

**Tünet B:** OOM / betöltési hiba helyi modelleknél.

**Ok:** túl nagyra állított context_length (pl. 1M) egy kis gépnek.

**Javítás:** a modell max értéke (pl. qwen3.5-9b → 262144), SOHA ne 1M.

---

## H5 — Új kedvenc LLM beállítása: a többszörös-írás csapda

Amikor Péter új modellt akar, a beállítás **több helyre** ír — és ha
valamelyik helyen maradék marad, jön a hiba. A teljes lista:

1. `config.yaml` → `model.provider` (melyik provider)
2. `config.yaml` → `model.default` (melyik modell)
3. `config.yaml` → `providers.<név>` (ha új provider: api_key, base_url,
   context_length, rate_limit_delay)
4. `config.yaml` → `auxiliary.*` (vision, curator, title stb. — külön modell)
5. `config.yaml` → `model.favorites` (F2 lista — label+model párok)
6. `.env` → API kulcsok (csak ide!)
7. `.env` → `HERMES_DEFAULT_MODEL` (csapda! felülírja a configot)

**A 3 fájl ami tönkremehet:** a default config.yaml, a .env, ÉS a
`profiles/` alatti config-ok. A `--clone` profilok (tui, hazi-feladat)
öröklik a hibát — ha a defaultban elrontasz valamit és utána klónozol,
a hiba átmegy. Ha a defaultban javítasz, a klónokat is javítani kell.

**Biztonságos recept új modellhez:**
```bash
# 1) backup
cp config.yaml config.yaml.bak-<dátum>

# 2) jelenlegi állapot
grep -A5 '^model:' config.yaml
grep -n "HERMES_DEFAULT_MODEL" .env

# 3) módosítás (példa)
hermes config set model.provider <név>
hermes config set model.default <modell>

# 4) MINDEN profil ellenőrzése
for p in tui hazi-feladat qwenticoo; do
  echo "== $p =="; grep -A5 '^model:' "/c/Users/fekec/AppData/Local/hermes/profiles/$p/config.yaml" 2>/dev/null || echo "NINCS config.yaml"
done

# 5) teszt — tényleges API hívás, nem csak config nézés!
```

---

## H6 — qwenticoo profil: nincs config.yaml

**Tünet:** F2 (model favorites) nem működik, a /model menü mást mutat, a
config show a defaultot adja vissza.

**Ok:** a qwenticoo profil `--clone` NÉLKÜL lett létrehozva → nincs saját
`config.yaml`-ja → a beépített defaultot használja, amiben nincs
model.favorites/providers.

**Javítás:** profilonkénti config:
```bash
HERMES_HOME=profiles/qwenticoo hermes config set --force <kulcs> <érték>
```
Vagy: `cp` a default config.yaml-ból a profiles/qwenticoo/-ba, majd átírni.

---

## H7 — HERMES_HOME a profiles/ gyökérre → hamis "logs" profil

Ha a HERMES_HOME-ot a `profiles/` mappára állítod (nem egy konkrét
profilra), a Hermes a profiles/ alatt kezd el dolgozni — üres "logs" és
egyéb hamis mappák jelennek meg.

**Szabály:** HERMES_HOME mindig egy KONKRÉT profil mappája legyen
(`profiles/<név>`), vagy a gyökér (default).

---

## H8 — hermes frissítés felülírja a fork-ot

**Tünet:** `unknown method: model.favorites` (F2 nem működik), a computer
use nem tudja az asztalt, a menük eltűnnek.

**Ok:** a `pip install -U hermes-agent` FELÜLÍRJA a site-packages-ben:
- `tui_gateway/server.py` — a Model Favorites szekció elveszik
- `tools/computer_use/` — a cua_backend auto-revive elveszik
- `hermes_cli/tui_dist/entry.js` — a fork build elveszik

**Javítás:** lásd 04_build_deploy.md — a forrásból visszamásolni a
site-packages-be. Ellenőrzés frissítés után:
1. `hermes --version`
2. F2 → működik-e a favorites?
3. Computer use → látja-e az asztalt?
4. File → Súgó → nyílik-e?

---

## H9 — NVIDIA NIM 429 (rate limit)

**Tünet:** `429 Too Many Requests` — a NVIDIA NIM 40 kérés/percet enged.

**Javítás:** `providers.nvidia.rate_limit_delay=1500` (1.5s kérés közt) +
`delegation.max_concurrent_children=1` (széria, nem párhuzamos) +
`parallel_tool_call_guidance=false`. 429-nél ~60s várni (Retry-After ha van).

---

## H10 — FLM XRT hiba: ÜRES 200-as válasz

**Tünet:** a FLM (FastFlowLM) XRT hibánál **üres 200-as HTTP választ** ad —
nem hibakódot. Ha csak a HTTP státuszt nézed, azt hiszed, minden OK.

**Javítás:** teszteléskor a válasz `content`-jét is nézni, nem csak a
státuszt. Kontextus: 262144 nem fér az NPU-ba (XRT 0xc01e0200) → 131072 a
maximum, ami működik.

---

## H11 — config.yaml sérülés (corrupt)

A `C:\Users\fekec\AppData\Local\hermes\`-ban több `config.yaml.corrupt.*.bak`
fájl található — ezek korábbi sérülések mentései (hibás YAML írás, félbe-
szakadt mentés).

**Szabály:** MINDEN config-módosítás előtt `cp config.yaml config.yaml.bak-<dátum>`.
Ha a config nem töltődik: a legfrissebb `.bak`-ból visszaállítani, és a
változtatást újra, óvatosan elvégezni (idézőjelek, kettőspontok!).

---

## H12 — Modellek, amikre vigyázni kell

| Modell | Probléma |
|---|---|
| `minimax-m3:cloud` | Érzelmi üzenetre ÖNHATALMÚ tool-használat (szerver kill + config törlés, 2026-08-01). Agent-modellnek NEM ajánlott |
| `nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free` | Vision: NÉMA FREEZE (content safety) |
| `meta/llama-3.2-11b-vision-instruct` | NVIDIA NIM-en timeout ~20s |
| Helyi 36B MoE (qwen3.6) | Vulkan driver regresszió óta nagyon lassú — cloud modellre váltani |

**Bevált cloud modellek:** gpt-oss:20b:cloud (Tier 1, leggyorsabb),
gemma4:31b:cloud, deepseek-v4-flash:cloud, nemotron-3-super:cloud.

---

## H13 — WSL VM auto-shutdown: az SFTP-teszt ECONNREFUSED/timeout

**Tünet:** a `sftp_transfer_test.ts` (vagy bármilyen WSL-elleni SSH/SFTP teszt)
néha "Timed out while waiting for handshake", néha "Kapcsolat elutasítva"
(ECONNREFUSED) — pedig a WSL-ben az sshd aktív és a 22-es port hallgat
(`ss -tln` mutatja), és a PowerShell `Test-NetConnection` is True-t mond.

**Ok:** a WSL2 VM **automatikusan leáll, amint nincs aktív WSL-folyamat**
(használaton kívül ~8-60s). A `wsl.exe -u root -e bash -lc '...'` parancs
elindítja a VM-et, a parancs végeztével a VM (és vele az sshd) leáll. A
következő teszt már a semmibe megy. A tünetek keverednek: timeout (a socket
még épp hallgat, de a szolgáltatás nem fogad) és ECONNREFUSED (a VM már leállt).

**Javítás teszteléshez — tartsd ébren a WSL-t a teszt alatt:**
```bash
# 1) háttérben ébren tartó folyamat a WSL-ben (terminal background=true!)
wsl.exe -u root -e bash -lc 'sleep 180'
# 2) sshd indítása/újraindítása
wsl.exe -u root -e bash -lc 'systemctl restart ssh.socket ssh; sleep 1; systemctl is-active ssh'
# 3) a teszt ezután megy
cd /c/tmp/herm_tui/forras/ui-tui && npx tsx ../scripts/sftp_transfer_test.ts
# 4) a háttér folyamat leállítása (process kill)
```
Az sshd socket-aktivált: az első kapcsolatnál indul — ezért a restart után
érdemes `systemctl enable ssh.socket`-ot is adni (így a VM indulásakor a
socket figyel). A TUI-ban a user kapcsolódásakor nincs gond (a TUI él, a VM
nem áll le menet közben), csak a külön teszt-futtatásoknál kell az ébrentartás.

---

## H14 — hermes 0.20.1: saját venv-ből fut (2026-08-14)

**Tünet:** a `which hermes` mostantól a `C:\Users\fekec\AppData\Local\hermes\
hermes-agent\venv\Scripts\hermes`-re mutat, nem a Programs-os Pythont használja.

**Ok:** a hermes 0.20.1 (2026-08-13) saját venv-et hozott létre önmagának
(`hermes-agent` mappa + `ui-tui/dist/entry.js` + `hermes_cli`), ami megváltoztatja
a "site-packages-be másolás" útvonalát.

**Javítás a fork aktualizálásához 0.20.1-en:** a fork buildjét és a Python
módosításokat (server.py Model Favorites, tools/computer_use, entry.js) nem a
Programs-os site-packages-be, hanem a **saját venv site-packages-ébe** kell
másolni (`C:\Users\fekec\AppData\Local\hermes\hermes-agent\...\site-packages\`).
Követés: `hermes --version`, `which hermes`.

> A pendrive-csomag (0.19.0) receptje továbbra is a 0.19.0-s site-packages
> elrendezést írja le — a célgépen ez a helyes.

## H14 — FP jelzés eltűnt a frissítés után (0.20.4 gateway eseményformátum)

**Tünet:** a felső menüsorban nem jelenik meg a sárga `FP n` jelzés (a
feladat során szerkesztett fájlok száma), pedig az agent ír/módosít fájlokat.
(Az [FP] lista és a Manager → FP — feladat szerkesztett fájljai is üres.)

**Ok:** a 0.20.4 gateway `tool.start` eseménye már NEM küldi az `args_path`
mezőt (a fork 0.19-ben még küldte), és az `args_text` csak verbose módban
jön (`_session_verbose`). A TUI FP-gyűjtője (`fpStore.collectFpFile`) csak
ezekre várt → üres maradt, a badge nem jelent meg. A gateway MAGJA változott,
nem a fork-szekció — a reapply script ezt nem állítja vissza.

**Javítás (2026-08-21):** a TUI a gateway által küldött teljes `args` dictből
nyeri ki a fájl útvonalat (`JSON.stringify(args)` → `extractArgPath`, ami a
`path` mezőt és a V4A `*** Update File:` sort is felismeri):
- `ui-tui/src/app/createGatewayEventHandler.ts` — a `tool.start` ág
- `ui-tui/src/gatewayTypes.ts` — `args?: Record<string, unknown>` a payloadban

**Tanulság:** a frissítések nem csak a fork RPC-szekciókat és az
entry.js-t írják felül — a gateway MAGJÁNAK eseményformátuma is változhat,
amire a fork funkciók épülnek (FP, tool progress). Ilyenkor a TUI oldalt
kell a JELENLEGI formátumhoz igazítani (a gateway-t nem szabad foltozni).

**Ellenőrzés frissítés után:** írj/módosíts egy fájlt → a menüsorban
megjelenik-e az `FP n` badge?

## H15 — Sok teszt bukik frissítés/build után: a renderSync-as tesztek ASZINKRON olvasnak

**Tünet:** a `npm run check` (vagy `npx vitest run`) után hirtelen SOK teszt
bukik egy overlay tesztfájlban (2026-08-21: a subscriptionOverlay 19/25-e),
miközben a kód és a komponensek NEM változtak — a hibaüzenet mindig üres
kimenet (`expected '' to contain ...`).

**Ok — két csapda egymásra rakva:**
1. A hermes-ink `renderSync` kimenete a teszt PassThrough-jára a `'data'`
   eseménnyel **ASZINKRON** érkezik. A teszt, ami a `renderSync` hívása után
   AZONNAL olvassa az outputot (`mounted.output()`), üres stringet kap.
   A jó minta a `brandingMcpCount.test.ts`: `await delay(20)` a kiolvasás előtt.
2. A vitest `useFakeTimers()` a `setImmediate`-t IS fake-eli (a default
   toFake listában van) → a render írása (ami setImmediate-tel megy) fake
   timer alatt SOSEM fut le → még a várakozás sem segít, az output üres marad.

**Javítás (2026-08-21, commit `e1e97776`):**
- A teszt `render()` függvénye legyen `async`, és a kiolvasás előtt:
  `await new Promise(r => setTimeout(r, 20))` (a PassThrough 'data' megérkezik).
- A `useFakeTimers`-es teszteknél: `vi.useFakeTimers({ toFake: ['setTimeout',
  'clearTimeout', 'setInterval', 'clearInterval', 'Date'] })` — a setImmediate
  VALÓDI marad → a render ír; a kiolvasás előtt:
  `await new Promise(r => setImmediate(r))`.
- A `mounted.rerender()` után is kell egy setImmediate-várakozás (a rerender
  írása is aszinkron).

**Tanulság — frissítés után NEM elkönyvelni „pre-existing"-nek:** a sok
bukott tesztnél ELŐBB megkeresni a közös gyökeret (stash-próba + a
legutóbbi build/commit diff). Gyakran a TESZT a rossz (aszinkron
kiolvasás), nem a komponens — a valódi TUI közben jól működik.

**Ellenőrzés:** `npx vitest run src/__tests__/subscriptionOverlay.test.tsx`
→ 25/25 zöld. (Maradék ismert: `ink-backpressure` 1 teszt —
`queueMicrotask` + szinkron teszt, a TUI-t nem érinti.)

---

## H16 — F4 Memtest: "Üzenetek: 0" és "Kontext: 0/0 token" (2026-08-21)

**Tünet:** az F4 Memtest panel "Beszélgetés" szekciójában az "Üzenetek: 0"
mutatja, miközben az API hívás száma nő és a SessionDB-ben ott vannak az
üzenetek. (Előtte a "Kontext: 0 / 0 token (0%)" is 0 volt.)

**Ok — két külön dolog:**
1. **Kontext 0/0:** a `context_used` a compressor `last_prompt_tokens`-jéből
   jön — ha a sessionben még NEM futott le API hívás (friss session, az F4
   az első üzenet előtt/után azonnal), akkor nincs mért érték → a `_get_usage`
   szándékosan nem ír `context_used`-öt, a panel 0-ra defaultol. Ez NEM hiba,
   csak "még nincs adat" (az első turn után számolni kezd).
2. **Üzenetek 0:** a selfcheck a `session["history"]` gateway-tükör hosszából
   számolt, ami üresen maradhat, ha:
   - az első turn **modell-fallbackje** (`qwen3.5:9b` nem fut → fallback
     `deepseek-v4-flash` a turn közben) `_append_model_switch_marker`-t szúr →
     `history_version` nő a turn alatt → a turn végén `history_version
     mismatch` → a `session["history"] = result["messages"]` NEM fut le;
   - a későbbi user üzenetek **redirect-ként** érkeznek (`busy_input_mode:
     interrupt` + `agent.redirect` a futó turnbe — a naplóban NINCS új
     "tui prompt accepted" sor!) → nem új gateway-turn → a history frissítés
     nem fut. Az agent közben a SessionDB-be ír (a DB a valós üzenetszám).

**Javítás (2026-08-21):** a selfcheck `messages` mezője az agent élő
transcriptjéből számol, a history csak tartalék:
```python
_agent_msgs = getattr(agent, "_session_messages", None) if agent else None
if isinstance(_agent_msgs, list):
    _live_messages = len(_agent_msgs)
else:
    _live_messages = len(session.get("history", []) or [])
```
Érintett: `tui_gateway/server.py` (fork forrás + éles) és
`scripts/reapply_fork_tui.py` FORK_BLOCK-ja (frissítés-túlélő).

**Tanulság:** a gateway `session["history"]` tükör NEM mindig a valós
üzenetszám — modell-fallback (history_version mismatch) és redirect-bemenetek
mellett üresen maradhat, miközben az agent a DB-be ír. Megbízható forrás:
az agent `_session_messages` (élő transcript) vagy a SessionDB `message_count`.
A redirect-elt user üzenetek a naplóban nem jelennek meg "tui prompt accepted"
sorként — ez is árulkodó jel.

**Ellenőrzés:** TUI újraindítás (F10 → hermes --tui) után F4 — az "Üzenetek"
számának a SessionDB-hez (és a látható beszélgetéshez) kell igazodnia.

**Állapot: ✅ MEGOLDVA, TESZTELVE (2026-08-21 este, Péter):** az "Üzenetek"
számol a beszélgetéshez igazodva. Commit: `02513518` (fork forrás, lokális).

## H17 — "timeout: pet.cells" a TUI-ban (2026-08-24)

**Tünet:** a TUI naplójában/státuszában `error: timeout: pet.cells`.

**Mi az:** a TUI pet widget (petdex) `usePet.ts` steady-poll-ja folyamatosan
hívja a `pet.cells` RPC-t (a /pet váltásokra reaktívan, akkor is, ha nincs
pet engedélyezve). A `gatewayClient.ts` REQUEST_TIMEOUT_MS (alapból 120 mp,
`HERMES_TUI_RPC_TIMEOUT_MS` env, min 30 mp) alatt nem érkezett válasz.

**Ok:** a configban NINCS pet engedélyezve (nincs display.pet) → a szervernek
azonnal `enabled: False`-t kellene adnia; a timeout tehát NEM renderelési
lassúság, hanem a gateway NEM válaszolt időben: foglalt szálkészlet (más
lassú RPC — model.options, complete.path, sftp — a pool-ban), vagy épp
indult/akadt. A pet.cells a fork server.py-jában a POOL-ra van téve (nem
blokkolja a reader threadet) — frissítéskor ezt a listát ellenőrizni
(a server.py elején).

**Következmény:** kozmetikai — pet nélkül semmit nem ront el.

**Ha pet engedélyezve VAN és gyakori:** a spritesheet-renderelés lassú →
`hermes pets scale <kisebb>` vagy a HERMES_TUI_RPC_TIMEOUT_MS növelése.

---

## TUI/build hibák (T1-T3) — 2026-08-09

### T1 — ssh2 a buildben: `ReferenceError: __dirname is not defined`
**Tünet:** a telepített `hermes --tui` indításkor összeomlik a
`dnSftp.ts` → `ssh2` betöltésénél (poly1305.wasm).
**Ok:** az esbuild ESM-bundle-be bundlolja az ssh2-t, ami a `__dirname`-t
használja — ESM-ben nincs `__dirname`.
**Javítás:** a `ui-tui/scripts/build.mjs`-ben `external: ['ssh2']`, és az
ssh2 (a függőségeivel: asn1, bcrypt-pbkdf, safer-buffer, tweetnacl) a
`hermes_cli/tui_dist/node_modules/`-be kerül — a node onnan tölti CJS-ként.
**FIGYELEM:** frissítés után a tui_dist/node_modules elveszhet → a
pendrive `telepites.bat` visszarakja.

### T2 — .bat blokk-parse: `! was unexpected at this time`
**Tünet:** a .bat script elszáll a `for /f`/`if` blokkoknál.
**Ok:** a cmd a zárójeleket a blokk-szerkezethez számolja — egy
`echo ... (szöveg)...` idézőjel nélkül a blokkban ÚJ blokkot nyit →
a későbbi `!` váratlan helyre kerül.
**Javítás:** a zárójeleket escape-elni a blokkban: `^(szöveg^)`,
vagy a szöveget idézőjelbe tenni. (A `%~1` a blokkban parse-time üres —
használd a `%~1`-et közvetlenül, ne a belőle beállított változót.)

### T3 — MSYS `/tmp` ≠ `C:\tmp` (tesztelési csapda)
**Tünet:** a bash-ben a `/tmp` a felhasználói temp
(`C:\Users\<user>\AppData\Local\Temp`), NEM a `C:\tmp`.
**Javítás:** tesztfájloknál mindig a `/c/tmp/...` útvonalat használni,
és a Windows-parancsoknak (`cmd /c`, `python`) a `C:\...` formát adni.

### T4 — a patch tool túl-escape-eli a Windows-útvonal backslash-ét
**Tünet:** a patch után a TS-forrásban `C:\\\\Program Files\\\\...` (8
backslash) szerepel 2 helyett → a futó program rossz útvonalat kap, vagy a
build elszáll. (Előjött: 07-28, 07-31, 08-07 — menuBar.tsx útvonalak.)
**Javítás:** a TS-forrásban `\\` = 1 backslash. Patch után ELLENŐRIZNI:
`grep -n "útvonal" fájl.ts | cat -A` — a bájtszámot nézni, nem a képernyőt.
Ha túl-escape-elve lett: egyszerű Python `.replace()` a fájlon (a shell
escapinget kerülni — az is kavar), majd újra cat -A.
**Továbbá:** git-bash-ben a `C:\tmp\` backslash path eltörik (`\t` → TAB) —
`/c/tmp/` vagy `'C:\tmp'` (aposztrófok közt) kell.

### T5 — gh CLI letöltő szkript: 6 csapda (2026-08-23)

A `hermes_es_fork_letoltes.cmd` (GitHub verziók + fork overlay-ek letöltése
a `C:\tmp\tools\frissítéshez\`-be) első változatai elszálltak — mind kipróbálva,
a végső szkript működik. A csapdák:

1. **`gh api` NEM támogatja az `-o` (kimeneti fájl) flaget** —
   `unknown shorthand flag: 'o'`. Javítás: stdout átirányítás:
   `gh api <endpoint> > fájl.zip`.
2. **`gh api` + `Accept: application/octet-stream` a contents endpointon →
   HTTP 415** (`Unsupported 'Accept' header... Must accept 'application/json'`).
   A repo-gyökerű fájlokat (fork overlay zip-ek) így NEM lehet letölteni.
   Javítás: `gh api repos/<nev>/zipball/main > repo.zip` (a teljes repo zip)
   VAGY `git clone --depth 1 https://github.com/<nev>/<repo>.git` — a
   git.exe-nek nyitva a tűzfalon (gh-val együtt).
3. **Natív Windows programok (gh, git) az MSYS-útvonalat nem értik** —
   `--dir /c/tmp/tools` → "No matches found" (a gh máshová néz). Javítás:
   `--dir "C:/tmp/tools"` (Windows-formátum).
4. **`cmd //c script.cmd` a git-bash-ből interaktív módba esik** — nem futtat,
   csak a cmd-bannert + promptot írja, majd kilép. Javítás:
   `MSYS_NO_PATHCONV=1 cmd.exe /c "script.cmd"`.
5. **A .cmd-ben a `timeout /t 10` a git-bash PATH-jában a GNU timeout-ot
   találja meg** (`invalid time interval '/t'` — a Windows `timeout.exe`
   helyett a `/usr/bin/timeout` fut). Javítás:
   `%SystemRoot%\System32\timeout.exe /t 10` (teljes elérési út).
6. **A git-bash GNU tar-ja a zip-et nem bontja** (`This does not look like a
   tar archive`) — a Windows `C:\Windows\System32\tar.exe` (bsdtar) tudja;
   vagy git clone + `copy` a zip-ekre.

---

## Gyors diagnózis folyamatábra

```
Modell/config hiba?
│
├─ Connection error      → H1 (grep -A5 '^model:' config.yaml)
├─ Néma freeze (kép)     → H3 (hermes config show auxiliary.vision)
├─ Max length reached    → H4 (context_length)
├─ 429                   → H9 (rate limit)
├─ Üres válasz           → H10 (FLM — content-et nézni)
├─ unknown method        → H8 (frissítés felülírta a fork-ot)
├─ FP jelzés hiányzik    → H14 (0.20.4 gateway eseményformátum — args_path kikerült)
├─ Sok teszt bukik frissítés után → H15 (renderSync ASZINKRON kiolvasás + fake timer setImmediate)
├─ F4 Memtest: Üzenetek 0 / Kontext 0/0 → H16 (history-tükör + last_prompt_tokens — agent transcriptből számol)
├─ timeout: pet.cells → H17 (pet RPC — kozmetikai, a gateway nem válaszolt időben, pet nélkül ártalmatlan)
├─ F2 nem működik        → H6 (profil config hiányzik)
└─ Másik modell indul    → H2 (HERMES_DEFAULT_MODEL a .env-ben)

MINDIG: backup először, MINDEN profilt ellenőrizni, és a javítás után
TÉNYLEGES API hívással tesztelni — nem elég a configot nézni!
```
