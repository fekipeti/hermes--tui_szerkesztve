# 08 — Hátralévő fejlesztési terv (a 24 pont + a kisablakos chat)

Ez a fájl a **TUI-fork hátralévő fejlesztési munkáját** rögzíti, ahogy azt
Péter és az agent a beszélgetésekben megtervezte. Források:
`munkai\md\hermes\hermes tui\dn_terv_2026-08-02.md`,
`dn_menuk_2026-08-06.md`, `kisablakos_chat_terv_2026-08-09.md`.

Zsákmány-kérdésre gyors válasz: **a 24 pontból 15 kész + a 25., hátra 9.
A 6-os "mindenképp" lista TELJESEN lezárt (2026-08-18 — a Flat nézettel).**

---

## 1. A 24 pont (a DN-fájlkezelő bővítése) — állapot

A lista a dn_menuk "KIEGÉSZÍTETT ÁTEMELÉSI LISTA" (10-es top + 14 új) alapján.
Jelölés: ✅ kész (melyik kör) · 🔲 hátra.

| # | Pont | Állapot |
|---|------|---------|
| 1 | Quick dirs (gyors könyvtárak) — kedvenc mappák, egy gombos ugrás | ✅ KÉSZ (11. kör 2026-08-18, 18062d1d) |
| 2 | Sort by (rendezés: név/méret/dátum + fejléc-kattintás irányváltás) | ✅ KÉSZ (9. kör 2026-08-11, 14bdb7de) |
| 3 | Compare directories (két panel eltérései) | ✅ KÉSZ (15. kör 2026-08-21 — Ctrl+O / Manager menü; jelek [=] [≠] [<] [>], a FAR hagyománya szerint MEGJELÖLI a csak-egyik-oldali + újabb fájlokat → F5/F8; Tab/Shift+Tab = következő/előző eltérés; SFTP-nél csak méret) |
| 4 | Könyvtár-előzmények (Alt+←/→ vissza/előre, panelonként) | ✅ KÉSZ (9. kör, 14bdb7de) |
| 5 | Find / keresés (Alt-F7) a könyvtárban | ✅ KÉSZ (11. kör 2026-08-18, 18062d1d) |
| 6 | Csoport-kijelölés (Shift+↑/↓, Ins, Ctrl+A, Select group maszk) | ✅ KÉSZ (5. kör 2026-08-08, 0427ff28) |
| 7 | "Mindig ezzel" editor (az F3/F4 választó memóriája, dn.default_editor) | ✅ KÉSZ (12. kör 2026-08-18, M billentyű az F3/F4 menüben — a default a hermes home-ba mentve, a lista elejére kerül [✓] jelzéssel) |
| 8 | Calculator / Calendar / ASCII tábla | 🔲 hátra — **RÁÉR** (Péter 08-21: ha nem lesz meg, nem lesz meg) |
| 9 | Fájlszűrő (Advanced filter, pl. *.txt) a panelben | ✅ KÉSZ (13. kör 2026-08-20, c38f1f6c — Alt-Del, a könyvtárak mindig látszanak, [SZŰRŐ] jelzés) |
| 10 | Panel elrejtés (Ctrl+F1/F2/P, egyik panel kicsinyítése) | ✅ KÉSZ (14. kör 2026-08-20, 31082f03 — a maradék panel teljes szélességben; a Keresés is a Panel menübe került) |
| 11 | Encoding — kódolásváltás a belső nézőben/szerkesztőben | ✅ KÉSZ (9. kör 2026-08-12, 508fcf8a) |
| 12 | Csoportos átnevezés (Ctrl+M) — dialógus 2 móddal (maszk helyben / F6 a másik panelre) | ✅ KÉSZ (5. kör, 0427ff28) |
| 13 | Hash / ellenőrző fájl (SHA256 + vágólapra) | ✅ KÉSZ (5. kör, infó-panel [Hash] gomb) |
| 14 | Nevek vágólapra (Manager → Vágólapra ▸, 3 sor) | ✅ KÉSZ (5. kör, 0427ff28) |
| 15 | Hálózat (WSL a Change drive-ban + SFTP + letöltés/feltöltés) | ✅ KÉSZ (8. kör 2026-08-08, 361ad744 → d9ec9bef) |
| 16 | **Flat nézet (Ctrl+B)** — minden almappa fájlja egy listában | ✅ KÉSZ (10. kör 2026-08-18) |
| 17 | Mappaszinkronizálás (két mappa eltérései + szinkron) | 🔲 hátra |
| 18 | Fájl összehasonlítás / diff (két fájl tartalma) | ✅ KÉSZ (16. kör 2026-08-21 — Alt+D / Compare módban Enter a [≠] fájlon / Manager → Fájlok diff; két hasáb, piros = csak balon / zöld = csak jobbon, Tab = eltérés ugrás; auto-kódolás UTF-8→CP1250; SFTP-nél nem támogatott) |
| 19 | Becsomagolás/Kicsomagolás (Alt+F5/F9, 7z/tar motor + archívum-teszt) | ✅ KÉSZ (17. kör 2026-08-21 — Alt+F5 pack a másik panelre, Alt+F9 extract, Archívum teszt (7z t) a kontext menüben + Fájlműveletek ▸; a 7z a Program Files-ból (Ninite) → PATH → C:\tmp\tools fallback; a kiterjesztés dönti a formátumot (7z/zip/tar/gz/bz2/xz); a létező archívumot nem írja felül; SFTP-nél nincs) |
| 20 | Kijelölés mentése/visszaállítása (listába) | 🔲 hátra — **RÁÉR** (Péter 08-21: ha nem lesz meg, nem lesz meg) |
| 21 | Chmod / Link / Symlink (Linux jogok és linkek, WSL) | 🔲 hátra |
| 22 | Gyorsfeljegyzés a fájlhoz (Ctrl+Z, a Desc oszlophoz) | 🔲 hátra |
| 23 | Fájlkódolás (MIME/base64) — kódolás/dekódolás | 🔲 hátra |
| 24 | VFS — belépés az archívumba mappaként (a zip belülről böngészhető) | 🔲 hátra |
| 25 | Új fájl (File menü → txt/md/lnk/üres, csák DN módban) | ✅ KÉSZ (6. kör 2026-08-08, ea2138c8) |

**Kész:** 1, 2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 18, 19, 25  ← 18 pont (17 a 24-ből + a 25.)
**Hátra:** 8, 17, 20, 21, 22, 23, 24  ← 7 pont.

### A 6 pontos "mindenképp" lista (Péter kedvencei) — LECLÁRVA

1-6. **MIND KÉSZ** — Encoding, Csoportos átnevezés, Hash, Nevek vágólapra,
Hálózat és a **Flat nézet** is elkészült (2026-08-18, 10. kör).

### Értelmes fejlesztési sorrend (a hátralévőkből)

1. ~~Flat nézet (16)~~ **KÉSZ 2026-08-18**
2. ~~Quick dirs (1) + Find (5)~~ **KÉSZ 2026-08-18** (a napi fájlkezelés leghasznosabbjai)
3. ~~**"Mindig ezzel" editor (7)**~~ **KÉSZ 2026-08-18** — az F3/F4 menüben
   az **M** billentyű: a kijelölt néző/szerkesztő a default (a hermes home-ba
   mentve, újraindítás után is megmarad); a default a menü elejére kerül
   [✓ Mindig ezzel] jelzéssel
4. ~~**Fájlszűrő (9)**~~ **KÉSZ 2026-08-20** — Alt-Del, a könyvtárak mindig
   látszanak, [SZŰRŐ:maszk] jelzés a fejlécben
5. ~~**Panel elrejtés (10)**~~ **KÉSZ 2026-08-20** — Ctrl+F1/F2/P, a maradék
   panel teljes szélességben; a **Keresés** is a Panel menübe került
   (bal/jobb/mindkettő, [L]/[J] jelzéssel a találati listában)
6. ~~**Compare (3)**~~ **KÉSZ 2026-08-21** — Ctrl+O / Manager menü, a jelek
   [=] [≠] [<] [>], a FAR hagyománya szerint a csak-egyik-oldali + újabb
   fájlok MEGJELÖLŐDNEK (F5/F8 azokon dolgozik), Tab/Shift+Tab = ugrás az
   eltérések közt, SFTP-nél csak méret alapján; a sugo.md-ben a jelek
   jelentése.
   ~~**diff (18)**~~ **KÉSZ 2026-08-21** — Alt+D / Compare módban Enter a
   [≠] fájlon / Manager → Fájlok diff: a két fájl tartalmának LCS-összevetése
   két hasábban (piros = csak balon, zöld = csak jobbon), Tab = eltérés ugrás,
   auto-kódolás (UTF-8/CP1250), SFTP-nél nem támogatott. Következő:
   **Mappaszinkron (17)** — a párhuzamos panelek ereje
7. ~~**Becsomagolás (19)**~~ **KÉSZ 2026-08-21** — Alt+F5/F9 + Archívum
   teszt; a 7z a Program Files-ból (Ninite) → PATH → C:\tmp\tools fallback.
   **Calc/Calendar/ASCII (8)** — RÁÉR (Péter: ha nem lesz meg, nem lesz meg),
   **VFS (24), Kijelölés-mentés (20)** — RÁÉR,
   **Chmod/Link (21), Gyorsfeljegyzés (22), Fájlkódolás (23)** — a hosszú távú vég

> **Menü-átrendezés (2026-08-21, `74dd794c`):** a Manager menü kiürült
> (navigáció + Keresés + Compare), a fájlműveletek a **Panel →
> Fájlműveletek ▸** almenübe kerültek (Kijelölés, Vágólapra, F5–F8,
> Nézet/Szerkesztés/Frissítés) — hogy a menü ne legyen zsúfolt.

---

## 2. Kisablakos chat (kisablakos_chat_terv_2026-08-09) — TERV, nem kész

**Koncepció (Péter ötlete):** a TUI mellé egy KÜLÖN, kis ablak, ami CSAK a
chatet mutatja — hogy ne a félképernyős TUI-t bambulja, miközben az agent
(computer use) a háttérben dolgozik.

- KÜLÖN ablak (NEM a terminál kicsinyítése, NEM a TUI része)
- Méret: kb. a GitHub Copilot chatablaka — keskeny, oldalsó panel
- CSAK a user ↔ LLM párbeszéd; a munka (fájlkezelő, menük) a TUI-ban marad
- **Adatáramlás a két ablak közt (megoldandó):** a TUI egy chat-logot/naplót
  ír (fájl vagy socket), a kisablak azt olvassa és mutatja — szinkronban
- Minden mást a computer use-zal az agent lát

**Kérdések (nyitott):** technológia (mini Electron/WebView, második Windows
Terminal, a hermes-webui nézete?), indítás (TUI menüpont?), a chat-log formátuma
(a hermes-sessionök már mentődnek).

**Állapot:** 2026-08-14-ig **NEM készült el** — csak terv a
`munkai\md\hermes\hermes tui\kisablakos_chat_terv_2026-08-09.md`-ban.

## 3. Computer use stabilitása (a terv 3. pontja)

- A cua-driver lefagyott / unreachable lett ("3 egymást követő hiba után"),
  egyes weboldalaknál beragadt (2026-08-09)
- **RÉSZBEN MEGOLDVA:** 2026-08-09 frissítés 0.12.6 → **0.19.2**, a
  `cua_backend.py` auto-revive (session idle-TTL után azonos id-vel újraindít)
  a forkban + a pendrive-csomagban
- Hátra: a `hermes computer-use doctor` kimenetének vizsgálata, alternatív
  vezérlési út (böngésző CDP), timeout/retry finomhangolás

## 4. Kutatás: a nagy cégek computer use megoldásai (a terv 4. pontja)

Megnézni, milyen nagy cégek csináltak computer use klónokat / hasonlót —
tanulni, összehasonlítani a cua-driverrel, esetleg stabilabbra váltani.

- OpenAI — Operator (böngésző-agent) · Anthropic — Computer Use (Claude API)
- Google — Project Mariner / Gemini · Microsoft — OmniParser / UFO
- Nyílt: browser-use, Stagehand, UI-TARS, Playwright MCP

**Állapot:** kutatási jegyzet még nincs elkészítve (nyitott).

## 5. F6 Plugin → Gateway (ÚJ pont, 2026-08-18, Péter kérése)

**Fontos:** ez a HERMES FŐ NÉZET gombjára vonatkozik (a chat nézet, amikor
nincs fájlkezelő nyitva) — NEM a DN fájlkezelőre! A fájlkezelő F6-a
(„Áthelyez") VÁLTOZATLAN marad.

A Hermes fő nézet F6 gombja jelenleg **Plugins** — LECSERÉLENDŐ **Gateway**-re.
Az F6 egy gateway-overlayt (menüt) nyit, ami kezeli az "átjárót" (messaging
gateway: Telegram, Discord, WhatsApp...). Az átjáró állapota rendszeresen
zavar (megy/nem megy, aktív/nem aktív) — ez a menü teszi láthatóvá és
kezelhetővé egy gombbal.

**Funkciók az overlayben:**
- **Status** — fut-e éppen az átjáró (`hermes gateway status`)
- **List** — melyik profilnál aktív/nem aktív (`hermes gateway list` — a
  kimenete: ✓/✗ + running/not running, profilonként)
- **Start** — elindítás háttérben (`hermes gateway run` background / start)
- **Restart** — újraindítás
- **Stop** — leállítás
- (opcionális: Install/Uninstall szolgáltatásként, Setup platformok)

**Fontos — a kettős telepítés miatt az overlaynek jeleznie kell, melyik
"átjárót" kezeli:**
- A TUI a forkot futtatja (PATH-beli hermes, 0.19.0, 40 commit) — a TUI-ból
  indított gateway a forké
- A desktop app a pip-es telepítést indítja (hermes-agent 0.20.3,
  `C:\Users\fekec\AppData\Local\hermes\hermes-agent`)
- Az overlay mutassa a verziót/telepítést is, hogy ne tűnjön "itt aktív, ott
  nem aktív" rejtélynek

**Bekötés (a menüknél megszokott módon):**
- `menuBar.tsx` KEY_HINT_ITEMS: F6 Plugins → F6 Gateway (+ a felső menüsor
  Plugins menüpont szintén)
- `useInputHandlers.ts` F6 ág: overlayStore új kulcs (`gatewayHub`)
- Új overlay komponens: `components/gatewayHub.tsx` (a pluginsHub mintájára)
- A TUI backend felől: `tui_gateway` egy `gateway.status` RPC, ami a
  `hermes gateway status/list` kimenetét adja (nem kell shell-hívás a
  frontendből)

**Állapot:** 🔲 tervbe véve 2026-08-18, még nem készült el.

---

## Források és hivatkozások

- `munkai\md\hermes\hermes tui\dn_terv_2026-08-02.md` — az F3/F4/FP alapok
- `munkai\md\hermes\hermes tui\dn_menuk_2026-08-06.md` — a döntések háza,
  a 24 pont felbontásban, körönként (6-9. kör részletei)
- `munkai\md\hermes\hermes tui\kisablakos_chat_terv_2026-08-09.md` — a
  kisablakos chat + computer use + kutatás terv

*Frissítve: 2026-08-21 (diff + Becsomagolás KÉSZ, hátra 7 pont — Mappaszinkron következik).*
