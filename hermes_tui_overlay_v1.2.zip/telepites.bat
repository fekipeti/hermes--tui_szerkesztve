@echo off
chcp 65001 >nul
setlocal

echo ============================================================
echo   Hermes TUI - pendrive telepito (overlay)
echo   A csomag TUI-fajljait masolja a telepitesre, backup-pal.
echo ============================================================
echo.

REM --- 1. site-packages megkeresese ---------------------------------
set "SP="
if not "%~1"=="" (
    set "SP=%~1"
    echo [teszt mod] site-packages parametkent: %~1
) else (
    for /f "delims=" %%i in ('python -c "import site; print(site.getsitepackages()[0])" 2^>nul') do set "SP=%%i"
    if not defined SP (
        for /f "delims=" %%i in ('py -3.13 -c "import site; print(site.getsitepackages()[0])" 2^>nul') do set "SP=%%i"
    )
)

if not defined SP (
    echo.
    echo [HIBA] Nem talalom a Python site-packages mappajat!
    echo   - Telepitsd a Pythont: https://www.python.org/downloads/
    echo   - Vagy add meg a mappat parametkent:  telepites.bat C:\path\site-packages
    echo.
    pause
    exit /b 1
)
if not exist "%SP%" (
    echo [HIBA] A megadott mappa nem letezik: %SP%
    pause
    exit /b 1
)
echo [1/4] site-packages: %SP%

REM --- 2. hermes verzio ellenorzese ---------------------------------
set "VER="
for /f "tokens=2" %%v in ('python -m pip show hermes-agent 2^>nul ^| findstr /i "Version:"') do set "VER=%%v"
if defined VER (
    echo [2/4] hermes-agent verzio: %VER%
    if not "%VER%"=="0.19.0" (
        echo.
        echo   FIGYELEM: ez a csomag a hermes-agent 0.19.0-hoz keszult!
        echo   Nalad %VER% van - lehet, hogy nem kompatibilis.
        echo   A biztonsagos valtozat:  python -m pip install hermes-agent==0.19.0
        echo.
    )
) else (
    echo [2/4] FIGYELEM: a hermes-agent nem talalhato ^(python -m pip show hermes-agent^)!
    echo   Telepites:  python -m pip install hermes-agent==0.19.0
    echo.
)

REM --- 3. a csomag fajljainak ellenorzese ---------------------------
set "MISSING="
if not exist "%~dp0hermes_cli\tui_dist\entry.js"     set "MISSING=%MISSING% entry.js"
if not exist "%~dp0hermes_cli\tui_dist\node_modules\ssh2\lib\index.js" set "MISSING=%MISSING% node_modules\ssh2"
if not exist "%~dp0tui_gateway\server.py"            set "MISSING=%MISSING% server.py"
if not exist "%~dp0tools\computer_use\cua_backend.py" set "MISSING=%MISSING% cua_backend.py"
if defined MISSING (
    echo [HIBA] Hianzo fajlok a csomagbol:%MISSING%
    pause
    exit /b 1
)
echo [3/4] A TUI-fajlok megvannak a csomagban (entry.js + ssh2 + server.py + cua_backend.py).

REM --- 4. backup + masolas ------------------------------------------
if not exist "%SP%\hermes_cli\tui_dist"       mkdir "%SP%\hermes_cli\tui_dist"
if not exist "%SP%\tui_gateway"               mkdir "%SP%\tui_gateway"
if not exist "%SP%\tools\computer_use"        mkdir "%SP%\tools\computer_use"

if not exist "%SP%\hermes_cli\tui_dist\entry.js.bak" (
    copy /y "%SP%\hermes_cli\tui_dist\entry.js" "%SP%\hermes_cli\tui_dist\entry.js.bak" >nul 2>&1
    if exist "%SP%\hermes_cli\tui_dist\entry.js.bak" echo   backup kesz: entry.js.bak
)
if not exist "%SP%\tui_gateway\server.py.bak" (
    copy /y "%SP%\tui_gateway\server.py" "%SP%\tui_gateway\server.py.bak" >nul 2>&1
    if exist "%SP%\tui_gateway\server.py.bak" echo   backup kesz: server.py.bak
)
if not exist "%SP%\tools\computer_use\cua_backend.py.bak" (
    copy /y "%SP%\tools\computer_use\cua_backend.py" "%SP%\tools\computer_use\cua_backend.py.bak" >nul 2>&1
    if exist "%SP%\tools\computer_use\cua_backend.py.bak" echo   backup kesz: cua_backend.py.bak
)

copy /y "%~dp0hermes_cli\tui_dist\entry.js"     "%SP%\hermes_cli\tui_dist\entry.js"     >nul && echo   entry.js    -> OK
if not exist "%SP%\hermes_cli\tui_dist\node_modules" mkdir "%SP%\hermes_cli\tui_dist\node_modules"
xcopy /e /i /y "%~dp0hermes_cli\tui_dist\node_modules\ssh2"        "%SP%\hermes_cli\tui_dist\node_modules\ssh2"        >nul && echo   ssh2         -> OK
xcopy /e /i /y "%~dp0hermes_cli\tui_dist\node_modules\asn1"        "%SP%\hermes_cli\tui_dist\node_modules\asn1"        >nul && echo   asn1         -> OK
xcopy /e /i /y "%~dp0hermes_cli\tui_dist\node_modules\bcrypt-pbkdf" "%SP%\hermes_cli\tui_dist\node_modules\bcrypt-pbkdf" >nul && echo   bcrypt-pbkdf -> OK
xcopy /e /i /y "%~dp0hermes_cli\tui_dist\node_modules\safer-buffer" "%SP%\hermes_cli\tui_dist\node_modules\safer-buffer" >nul && echo   safer-buffer -> OK
xcopy /e /i /y "%~dp0hermes_cli\tui_dist\node_modules\tweetnacl"   "%SP%\hermes_cli\tui_dist\node_modules\tweetnacl"   >nul && echo   tweetnacl    -> OK
copy /y "%~dp0tui_gateway\server.py"            "%SP%\tui_gateway\server.py"            >nul && echo   server.py   -> OK
copy /y "%~dp0tools\computer_use\cua_backend.py" "%SP%\tools\computer_use\cua_backend.py" >nul && echo   cua_backend -> OK

echo.
echo [4/4] KESZ! A TUI fajlok felulirva.
echo   Inditas:          hermes --tui
echo   Visszaallitas:    a .bak fajlok atnevezesevel (entry.js.bak -^> entry.js stb.)
echo.
pause
