# Hermes — módosítások és programok (2026-08-09)

A lista célja: mi változott a tiszta hermes-hez képest a TUI-forkban,
és milyen programok kellenek a TUI menüihez (verzió + netes elérés +
telepítési útvonal).

---

## 1. A venv-teszt (tiszta hermes) — megvan-e?

**IGEN, megvan:** `C:\tmp\hermes_venv_teszt` (187 MB site-packages)

- Tiszta `hermes-agent==0.19.0` pip-telepítés (a célgép szimulációja)
- Rákerült az overlay (a pendrive csomag) — a TUI elindult és futott
- Ez a tesztkörnyezet — ha már nem kell, törölhető (a mappa törlése elég)

## 2. Mit használsz te valójában? (a fork)

- **A fork:** `C:\tmp\herm_tui\forras` — a teljes hermes forrás + 28 commit
  (ebből 27 a te TUI-munkád + 1 upstream fix)
- A TUI-t a forkból indítod: `npm start` (ui-tui mappában) — MINDEN a forrásból
- A telepített hermes (`hermes --tui` a site-packages-ből) — mostantól a
  pendrive-overlay-jel frissítve (ugyanaz a TUI)

## 3. A fork módosításai a tiszta hermes-hez képest

### 3.1 DN fájlkezelő (a legnagyobb blokk)
- Kétpaneles, DOS Navigator stílusú fájlkezelő (Manager → FP / OLD)
- DN menüsor: File / Hermes / Utilities / Panel / Manager / Options / Window
- Fájlműveletek: F5 Másolás, F6 Áthelyezés, F7 Új mappa, F8 Törlés (Lomtárba)
- Többszörös kijelölés (Shift+↑/↓), csoportos átnevezés, hash, vágólap
- Új fájl létrehozása (File menü, csak DN módban — dnOnly)
- DN-menük szürkítése Hermes módban (dnDisabled)
- Panelek alatti adat-widgetek (meghajtó, szabad hely, könyvtár, kijelölt fájl)
- **Hálózat:** WSL meghajtó a Change drive-ban + SFTP (ssh2) böngészés,
  letöltés/feltöltés (jelszó nem marad meg)

### 3.2 Menük és indítók
- Hermes menü → Session almenü: `/sessions`, `/new`, `/resume last`
- Utilities (Eszközök) menü: Thunderbird (F8), AIMP (F9), tldraw offline,
  ComfyUI, Hermes & PC (cua-driver), Ambient Widget rendszer
- File menü → Súgó (F1): a `help/sugo.md`-t nyitja a kedvenc MD-olvasóban
- Window menü: Teljes képernyő (Alt+Enter), Maximalizálás (Win+↑), stb.
- Skills menü takarítás + SkillCreator/SkillDelete overlay-ek

### 3.3 Billentyűk (a Ctrl+C — a te kérésed)
- **Ctrl+C:** CSAK másolás (ha van kijelölés) és interrupt (ha az AI válaszol)
  — NEM törli a beviteli mezőt, NEM lép ki a TUI-ból
- **F10:** az egyetlen kilépő billentyű
- F1-F10 funkciógomb-sor a DN módban

### 3.4 Nyelvi modellek
- **Model Favorites (F2):** kedvenc modellek mentése a configba
  (`model.favorites`), gyors váltás — a `tui_gateway/server.py`-ben
  (model.favorites + model.favorites.set RPC-k)
- **FIGYELEM:** a hermes frissítés felülírja a server.py-t → a Model
  Favorites eltűnik ("unknown method") → a pendrive telepítőjével
  visszarakható

### 3.5 Sessionok és profilok
- Session-picker + Profilkezelő overlay (session-picker stílusú,
  ↑↓ lista, Enter=profil váltás, Tab=almenü)
- A váltás a TUI újraindítása után lép életbe

### 3.6 Egyéb fork-módosítások
- FP gyűjtő: a tool-ok `args_path` mezőjének gyűjtése (menüsori FP jelzés)
- cua_backend auto-revive (a computer use session idle-TTL utáni újraindítása)
- Vágólap-másolás javítása (PowerShell Set-Clipboard base64 UTF-8 — az
  ékezetes karakterek helyesen másolódnak)
- tldraw indítás javítása (execFile + cmd.exe start)
- ssh2 a bundle-ből kivéve (external) — a build-javítás, amit ma csináltunk

### 3.7 A config beállításaid (a géped — nem a fork része)
- `model.favorites` — a kedvenc modellek (F2)
- `providers.nvidia` — rate_limit_delay: 1500 (a 429 elkerülésére)
- `auxiliary.vision` — nvidia/nemotron-nano-12b-v2-vl (a képelemzéshez)
- `delegation.max_concurrent_children: 1` — a subagent-ek szériában futnak
- `compression.enabled: false` — a tömörítés kikapcsolva
- `agent.max_turns: 4000`, `goals.max_turns: 3000`
- `appearance.file_mutation_verifier: false`
- `skills.disabled` — a letiltott skill-ek (a fájlok megmaradnak)

---

## 4. A Utilities menü programjai (verzió + netes elérés + útvonal)

| Program | Verzió | Netes elérés | Telepítési útvonal |
|---|---|---|---|
| Thunderbird | 153.0.1 | https://www.thunderbird.net/ | `C:\Program Files\Mozilla Thunderbird\thunderbird.exe` |
| AIMP | 5.4.0.2716 | https://www.aimp.ru/ | `C:\Program Files (x86)\AIMP\AIMP.exe` |
| tldraw offline | 1.12.0.0 | https://tldraw.com/ | `C:\Program Files\tldraw offline\tldraw offline.exe` |
| ComfyUI Desktop | 1.0.37.0 | https://www.comfy.org/ | `C:\Users\<felhasználó>\AppData\Local\Programs\ComfyUI\Comfy Desktop.exe` |
| cua-driver | 0.12.6 | (a Hermes része) | `hermes computer-use` (a Hermes telepíti) |
| Ambient Widget | — | (a TUI beépített része) | nincs külön telepítés |

## 5. Egyéb programok, amik a TUI-hoz kellenek / kapcsolódnak

| Program | Verzió | Netes elérés | Telepítési útvonal |
|---|---|---|---|
| Python | 3.13.14 | https://www.python.org/downloads/ | `C:\Users\<felhasználó>\AppData\Local\Programs\Python\Python313\` |
| Node.js | 26.7.0 | https://nodejs.org/ | `C:\Program Files\nodejs\` |
| hermes-agent | 0.19.0 | (pip) | site-packages (a Python mellett) |
| Blender | 5.2 | https://www.blender.org/ | `C:\Program Files\Blender Foundation\Blender 5.2\blender.exe` |
| WSL (Ubuntu) | — | https://learn.microsoft.com/windows/wsl/ | a Windows része |
| Git | 2.55.0 | https://git-scm.com/ | (csak fejlesztéshez kell) |

## 6. Ami a célgépen kell (a pendrive-csomaghoz)

1. Python 3.13.x (64-bit) — https://www.python.org/downloads/
2. Node.js 20+ — https://nodejs.org/
3. `python -m pip install hermes-agent==0.19.0`
4. A pendrive `telepites.bat` futtatása
5. A Utilities menü programjai (Thunderbird, AIMP, tldraw, ComfyUI) —
   a fenti netes elérésekről telepíthetők; nélkülük a menüpontok
   "program nem található" hibát adnak

---
*Készült: 2026-08-09. A verziók a gépről lekérdezve.*
