# F8 (Thunderbird email) és F9 (AIMP) — workflow leírás (2026-08-09)

A TUI funkciógombjainak működése, a hozzájuk tartozó programok
(verzió + netes elérés + telepítési útvonal) és a célgépre
telepítés lépései.

---

## F8 — Thunderbird email workflow

### Mit csinál az F8? (a gomb megnyomásakor)
1. **Temp mappa törlés:** lefut a `fix-tb-mcp-dir.ps1` PowerShell script
   (törli a `%TEMP%\thunderbird-mcp` mappát — ez a Thunderbird MCP
   Windows permission hibáját kerüli meg: az extensionnek magának kell
   frissen létrehoznia a mappát)
2. **Thunderbird indítása**
3. **Várakozás a `connection.json`-ra** (max 30 mp, 1 mp-enként poll)
   — ezt a Thunderbird MCP extension hozza létre
4. **MCP reload:** a Hermes újratölti az MCP-klienseket, ami
   automatikusan elindítja a bridge-et (`mcp-bridge.cjs`)
5. **'Mennyi email érkezett?'** beíródik a kompozícióba — az agent
   ezután a Thunderbird MCP-n keresztül lekérdezi az emaileket

**Megjegyzés:** DN overlay (fájlkezelő) módban az F8 a **Törlés
Lomtárba** művelet — a Thunderbird csak akkor indul, ha a fájlkezelő
nincs nyitva.

### Programok és fájlok

| Elem | Verzió / méret | Netes elérés | Útvonal |
|---|---|---|---|
| Thunderbird | 153.0.1 | https://www.thunderbird.net/ | `C:\Program Files\Mozilla Thunderbird\thunderbird.exe` |
| thunderbird-mcp | 0.7.4 | https://github.com/ (thunderbird-mcp) | `C:\Users\<felhasználó>\thunderbird-mcp\` |
| mcp-bridge.cjs | 38 KB | (a thunderbird-mcp része) | `C:\Users\<felhasználó>\thunderbird-mcp\mcp-bridge.cjs` |
| fix-tb-mcp-dir.ps1 | 430 B | (a mi scriptünk) | `C:\Users\<felhasználó>\AppData\Local\hermes\scripts\fix-tb-mcp-dir.ps1` |
| Node.js | 26.7.0 | https://nodejs.org/ | a bridge futtatója (`node`) |

### A config része (a Hermes config.yaml-ben)

```yaml
mcp_servers:
  thunderbird:
    args:
      - C:/Users/<felhasználó>/thunderbird-mcp/mcp-bridge.cjs
    command: node
    timeout: 60
```

### Fiókok
- Hotmail + Gmail — OAuth2-vel a Thunderbirdben
- A thunderbird-mcp 38 tool-t ad (olvasás, keresés, küldés, mappák)

### Célgépre telepítés lépései
1. Thunderbird 153+ telepítése (thunderbird.net)
2. A `thunderbird-mcp` mappa átmásolása (a bridge + extension + dist)
3. A Thunderbirdben a bővítmény engedélyezése + fiókok beállítása
   (Hotmail/Gmail OAuth2)
4. A `fix-tb-mcp-dir.ps1` átmásolása a hermes scripts mappájába
5. A config.yaml `mcp_servers.thunderbird` rész beállítása
6. A TUI-ban F8 → működnie kell

---

## F9 — AIMP (zenelejátszó)

### Mit csinál az F9?
**Egyszerű indítás** — nincs workflow, nincs MCP, csak elindítja az
AIMP-et. (A rádiócsatorna-váltás az AIMP saját felületén vagy a
media/aimp-radio-switcher skill-lel megy.)

### Program és fájl

| Elem | Verzió | Netes elérés | Útvonal |
|---|---|---|---|
| AIMP | 5.4.0.2716 | https://www.aimp.ru/ | `C:\Program Files (x86)\AIMP\AIMP.exe` |

### Célgépre telepítés lépései
1. AIMP 5.x telepítése (aimp.ru — a hivatalos oldal, ingyenes)
2. A TUI-ban F9 → működnie kell (a fenti útvonalra telepítve)

---

## A TUI kódban (hol van bekötve)

- `ui-tui/src/components/menuBar.tsx`:
  - 27-28. sor: a Thunderbird útvonal + fix script konstansai
  - 31-60. sor: a `launchThunderbird()` függvény (a 4 lépés)
  - 319-322. sor: az Utilities menü AIMP pontja
  - 776-798. sor: az F9/F8 billentyűkezelés
- A fájlkezelő F8-asa (Törlés): `ui-tui/src/components/dnPanelOverlay.tsx`
  (DN módban a fájlkezelő viszi az F8-at)

---
*Készült: 2026-08-09. Verziók a gépről lekérdezve.*
