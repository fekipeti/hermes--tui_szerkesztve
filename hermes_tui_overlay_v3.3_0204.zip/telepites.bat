@echo off
chcp 65001 >nul
setlocal

echo ============================================================
echo   Hermes TUI - 0.20.4 pendrive telepito (Peter fork)
echo   entry.js + ssh2 + fork server.py (0.20.4 gateway)
echo ============================================================
echo.

REM --- 1. a hermes TUI konyvtaranak megkeresese ----------------------
REM   Ketfele telepites lehet:
REM   A) editable:  %%LOCALAPPDATA%%\hermes\hermes-agent\ui-tui\dist\entry.js
REM   B) pip:       <site-packages>\hermes_cli\tui_dist\entry.js
set "TUI_DIR="
if not "%~1"=="" (
    set "TUI_DIR=%~1"
    echo [teszt mod] TUI konyvtar parametkent: %~1
) else (
    if exist "%LOCALAPPDATA%\hermes\hermes-agent\ui-tui\dist\entry.js" set "TUI_DIR=%LOCALAPPDATA%\hermes\hermes-agent\ui-tui\dist"
    if not defined TUI_DIR (
        for /f "delims=" %%i in ('python -c "import site,os; print(os.path.join(site.getsitepackages()[0],'hermes_cli','tui_dist'))" 2^>nul') do if exist "%%i\entry.js" set "TUI_DIR=%%i"
    )
    if not defined TUI_DIR (
        for /f "delims=" %%i in ('py -3.13 -c "import site,os; print(os.path.join(site.getsitepackages()[0],'hermes_cli','tui_dist'))" 2^>nul') do if exist "%%i\entry.js" set "TUI_DIR=%%i"
    )
)

if not defined TUI_DIR (
    echo.
    echo [HIBA] Nem talalom a hermes TUI-t!
    echo   - Telepitsd a hermes-t:  python -m pip install hermes-agent==0.20.4
    echo   - Vagy add meg a konyvtarat:  telepites.bat C:\path\ui-tui\dist
    echo.
    pause
    exit /b 1
)
if not exist "%TUI_DIR%\entry.js" (
    echo [HIBA] A megadott mappaban nincs entry.js: %TUI_DIR%
    pause
    exit /b 1
)
echo [1/5] TUI konyvtar: %TUI_DIR%

REM --- 2. hermes verzio ellenorzese -----------------------------------
set "VER="
for /f "tokens=2" %%v in ('python -m pip show hermes-agent 2^>nul ^| findstr /i "Version:"') do set "VER=%%v"
if defined VER (
    echo [2/5] hermes-agent verzio: %VER%
    if not "%VER%"=="0.20.4" (
        echo.
        echo   FIGYELEM: ez a csomag a hermes-agent 0.20.4-hez keszult!
        echo   Nalad %VER% van - a TUI lehet, hogy nem kompatibilis.
        echo   A biztonsagos valtozat:  python -m pip install hermes-agent==0.20.4
        echo.
    )
) else (
    echo [2/5] FIGYELEM: a hermes-agent nem talalhato ^(python -m pip show hermes-agent^)!
    echo   Telepites:  python -m pip install hermes-agent==0.20.4
    echo.
)

REM --- 3. a csomag fajljainak ellenorzese -----------------------------
set "MISSING="
if not exist "%~dp0hermes_cli\tui_dist\entry.js"     set "MISSING=%MISSING% entry.js"
if not exist "%~dp0hermes_cli\tui_dist\node_modules\ssh2\lib\index.js" set "MISSING=%MISSING% node_modules\ssh2"
if not exist "%~dp0tui_gateway\server.py"             set "MISSING=%MISSING% server.py"
if defined MISSING (
    echo [HIBA] Hianzo fajlok a csomagbol:%MISSING%
    pause
    exit /b 1
)
echo [3/5] A csomag fajljai megvannak (entry.js + ssh2 + fork server.py).

REM --- 4. backup + masolas -------------------------------------------
if not exist "%TUI_DIR%\entry.js.bak-0204" (
    copy /y "%TUI_DIR%\entry.js" "%TUI_DIR%\entry.js.bak-0204" >nul 2>&1
    if exist "%TUI_DIR%\entry.js.bak-0204" echo   backup kesz: entry.js.bak-0204
)
copy /y "%~dp0hermes_cli\tui_dist\entry.js" "%TUI_DIR%\entry.js" >nul && echo   entry.js      -^> OK
if not exist "%TUI_DIR%\node_modules" mkdir "%TUI_DIR%\node_modules"
xcopy /e /i /y "%~dp0hermes_cli\tui_dist\node_modules\ssh2"        "%TUI_DIR%\node_modules\ssh2"        >nul && echo   ssh2          -^> OK
xcopy /e /i /y "%~dp0hermes_cli\tui_dist\node_modules\asn1"        "%TUI_DIR%\node_modules\asn1"        >nul && echo   asn1          -^> OK
xcopy /e /i /y "%~dp0hermes_cli\tui_dist\node_modules\bcrypt-pbkdf" "%TUI_DIR%\node_modules\bcrypt-pbkdf" >nul && echo   bcrypt-pbkdf  -^> OK
xcopy /e /i /y "%~dp0hermes_cli\tui_dist\node_modules\safer-buffer" "%TUI_DIR%\node_modules\safer-buffer" >nul && echo   safer-buffer  -^> OK
xcopy /e /i /y "%~dp0hermes_cli\tui_dist\node_modules\tweetnacl"   "%TUI_DIR%\node_modules\tweetnacl"   >nul && echo   tweetnacl     -^> OK

REM --- 5. a fork server.py a gateway-be --------------------------------
REM   A fork TELJES RPC-szervere (sysinfo, filelock, vágólap, Model
REM   Favorites... RPC-k) — a tui_gateway mappaba. A gateway inditaskor ezt
REM   hasznalja; frissites utan a fork-RPC-k nelkule maradna a TUI.
set "GW_DIR=%TUI_DIR%\..\..\tui_gateway"
if not exist "%GW_DIR%" (
    echo [INFO] Nem talalom a tui_gateway mappat: %GW_DIR%
    echo        A fork RPC-k (sysinfo, filelock, vágólap...) nem lesznek elerhetok.
) else (
    if not exist "%GW_DIR%\server.py.bak-0204" (
        copy /y "%GW_DIR%\server.py" "%GW_DIR%\server.py.bak-0204" >nul 2>&1
        if exist "%GW_DIR%\server.py.bak-0204" echo   server.py backup kesz
    )
    copy /y "%~dp0tui_gateway\server.py" "%GW_DIR%\server.py" >nul && echo   server.py     -^> OK
)

echo.
echo [5/5] KESZ! A fork TUI feltelepítve.
echo   Inditas:          hermes --tui
echo   Visszaallitas:    a entry.js.bak-0204 atnevezesevel entry.js-re
echo.
pause
