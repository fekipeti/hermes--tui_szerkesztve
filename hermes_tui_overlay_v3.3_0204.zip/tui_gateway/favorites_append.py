# ── Model Favorites (Péter TUI fork) — 0.20.3 overlay ─────────────────────
# Ezt a blokkot a telepites_0203.bat a 0.20.3-as tui_gateway/methods_config.py
# végére fűzi, ha még nincs benne a "model.favorites". A @method dekorátor a
# modul importjakor a HandlerRegistry-be regisztrál, ezért a fájl végén is
# működik (a register() mindent begyűjt).


@method("model.favorites")
def _(rid, params: dict) -> dict:
    """Return the user's favorite model list from config.yaml.

    Reads ``model.favorites`` from the user config. Each entry is an object
    with ``label`` (display name) and ``model`` (full argument string passed
    to ``/model``, e.g. ``"qwen3.6 --provider ollama"``).
    """
    try:
        from hermes_cli.config import load_config

        cfg = load_config()
        raw = cfg.get("model", {}).get("favorites", [])
        favorites = []
        for entry in raw:
            if isinstance(entry, str):
                favorites.append({"label": entry, "model": entry})
            elif isinstance(entry, dict):
                favorites.append({
                    "label": entry.get("label", entry.get("model", str(entry))),
                    "model": entry.get("model", entry.get("label", str(entry))),
                })
        try:
            current_model = _resolve_model()
        except Exception:
            current_model = ""
        return _ok(rid, {"favorites": favorites, "model": current_model})
    except Exception as e:
        return _err(rid, 5034, str(e))


@method("model.favorites.set")
def _(rid, params: dict) -> dict:
    """Save a complete favorites list to config.yaml.

    Params:
        favorites: list of {label, model} dicts

    Replaces the entire ``model.favorites`` config value.
    """
    try:
        from cli import save_config_value

        raw = params.get("favorites", [])
        cleaned = []
        for entry in raw:
            if isinstance(entry, dict) and entry.get("label") and entry.get("model"):
                cleaned.append({"label": str(entry["label"]), "model": str(entry["model"])})
            elif isinstance(entry, str):
                cleaned.append({"label": entry, "model": entry})
        save_config_value("model.favorites", cleaned)
        return _ok(rid, {"saved": True, "count": len(cleaned)})
    except Exception as e:
        return _err(rid, 5035, str(e))
