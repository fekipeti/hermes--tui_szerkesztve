# Hermes — módosítások és programok (2026-08-17, 0.20.3)

A lista célja: mi változott a tiszta hermes-hez képest a TUI-forkban,
és milyen programok kellenek a TUI menüihez (verzió + netes elérés +
telepítési útvonal).

---

## 1. Mit használsz te valójában? (a fork)

- **A fork forrása:** `C:\tmp\herm_tui\forras` — a teljes hermes forrás +
  a TUI-committek (DN fájlkezelő, belső néző/szerkesztő, kódolásváltók,
  Model Favorites, kontextusfüggő F10...).
- **Fejlesztés:** a fork ui-tui mappájából `npm start` (minden a forrásból).
- **A telepített hermes** (`hermes --tui`) a 0.20.3-mal a
  `%LOCALAPPDATA%\hermes\hermes-agent` alól fut (editable telepítés), a
  TUI buildje a `hermes-agent\ui-tui\dist\entry.js`.
- **A pendrive-csomag** a `C:\tmp\pendrive2` mappából készül (a friss fork
  állapotból, 0.20.3-hoz).

## 2. A fork módosításai a tiszta hermes-hez képest

### 2.1 DN fájlkezelő (a legnagyobb blokk)
- Kétpaneles, DOS Navigator stílusú fájlkezelő (Manager → FP / OLD)
- DN menüsor: File / Hermes / Utilities / Panel / Manager / Options / Window
- Fájlműveletek: F5 Másolás, F6 Áthelyezés, F7 Új mappa, F8 Törlés (Lomtárba)
- Többszörös kijelölés (Shift+↑/↓), csoportos átnevezés, hash, vágólap
- Új fájl létrehozása (File menü, csak DN módban — dnOnly)
- DN-menük szürkítése Hermes módban (dnDisabled)
- Panelek alatti adat-widgetek (meghajtó, szabad hely, könyvtár, kijelölt fájl)
- **Hálózat:** WSL meghajtó a Change drive-ban + SFTP (ssh2) böngészés,
  letöltés/feltöltés (jelszó nem marad meg)

### 2.2 Belső néző / belső szerkesztő
- **F3 = Belső néző** (csak nézésre való; az F3 menüje külön tartalmazza a
  Notepad/VS Code/Megnyitás mással lehetőségeket is)
- **F4 = Belső szerkesztő** (nano/gedit/mcedit/Notepad++/Belső szerkesztő)
- **Kódolásváltók a belső szerkesztőben: F2-F9** (UTF-8, cp1250, cp852,
  ISO-8859-2, egyéb), **F8 = Hex**, **F9/F10 = mentés / vissza**
  — a kék menüből minden fókuszból működnek
- Kontextusfüggő F10: a fájlkezelőből Hermes-be lép vissza, a menüből a menüt
  zárja be, a szerkesztőből a fájlkezelőbe visz vissza; csak a fő nézetből
  lehet kilépni
- A belső szerkesztőből visszatérve a kurzor visszaugrik a szerkesztett fájlra
- 3 rétegű F-gombsor; a szerkesztő alatt a DN parancssor elrejtve

### 2.3 Menük és indítók
- Hermes menü → Session almenü: `/sessions`, `/new`, `/resume last`
- Utilities (Eszközök) menü: Thunderbird (F8), AIMP (F9), tldraw offline,
  ComfyUI, Hermes & PC (cua-driver), Ambient Widget rendszer
- File menü → Súgó (F1): a `help/sugo.md`-t nyitja a kedvenc MD-olvasóban
- Window menü: Teljes képernyő (Alt+Enter), Maximalizálás (Win+↑), stb.
- Skills menü takarítás + SkillCreator/SkillDelete overlay-ek

### 2.4 Billentyűk (a Ctrl+C — a kérésed)
- **Ctrl+C:** CSAK másolás (ha van kijelölés) és interrupt (ha az AI válaszol)
  — NEM törli a beviteli mezőt, NEM lép ki a TUI-ból
- **F10:** az egyetlen kilépő billentyű (kontextusfüggő — lásd 2.2)
- F1-F10 funkciógomb-sor a DN módban

### 2.5 Model Favorites (F2)
- Kedvenc modellek mentése a configba (`model.favorites`), gyors váltás
- 0.20.3-mal: a `model.favorites` + `model.favorites.set` RPC a
  `tui_gateway\methods_config.py`-ban van (a pendrive telepítő hozzáfűzi,
  ha a frissítés felülírta)
- **FIGYELEM:** a hermes frissítés felülírhatja a methods_config.py-t →
  a Model Favorites eltűnik ("unknown method") → futtasd újra a
  telepites.bat-ot

### 2.6 Egyéb fork-módosítások
- FP gyűjtő: a tool-ok `args_path` mezőjének gyűjtése (menüsori FP jelzés)
- Session-picker + Profilkezelő overlay
- Vágólap-másolás javítása (PowerShell Set-Clipboard base64 UTF-8 — az
  ékezetes karakterek helyesen másolódnak)
- tldraw indítás javítása (execFile + cmd.exe start)
- ssh2 a bundle-ből kivéve (external) — a build-javítás (lásd alább)

## 3. A 0.20.3 overlay — MIT MÁSOL A TELEPÍTŐ?

| Fájl a célgépen | Honnan (csomag) | Mit ad |
|---|---|---|
| `ui-tui\dist\entry.js` (editable) VAGY `hermes_cli\tui_dist\entry.js` (pip) | `hermes_cli\tui_dist\entry.js` | A teljes TUI: DN, menük, SFTP, widgetek |
| `node_modules\ssh2` (+asn1, bcrypt-pbkdf, safer-buffer, tweetnacl) az entry.js mellé | `hermes_cli\tui_dist\node_modules\` | Az SFTP futásidejű modulja |
| `tui_gateway\methods_config.py` (hozzáfűzés) | `tui_gateway\favorites_append.py` | A Model Favorites RPC-k |

**NEM kell felülírni 0.20.3-mal** (a gateway már tudja):
- `tui_gateway\server.py` — minden RPC benne van (session.*, system.battery,
  voice.*, shell.exec, tools.configure...)
- `tools\computer_use\cua_backend.py` — az auto-revive fix már benne van

## 4. A Utilities menü programjai (a célgépen is kellenek!)

A TUI Utilities (Eszközök) menüje ezeket indítja — a menüpontok csak akkor
működnek, ha a program telepítve van. Az útvonalak dinamikusak
(`os.homedir()`), a felhasználónév NINCS a kódban.

| Program | Verzió | Netes elérés | Telepítési útvonal |
|---|---|---|---|
| Thunderbird | 153.x | https://www.thunderbird.net/ | `C:\Program Files\Mozilla Thunderbird\thunderbird.exe` |
| AIMP | 5.4.x | https://www.aimp.ru/ | `C:\Program Files (x86)\AIMP\AIMP.exe` |
| tldraw offline | 1.12.x | https://tldraw.com/ | `C:\Program Files\tldraw offline\tldraw offline.exe` |
| ComfyUI Desktop | 1.0.x | https://www.comfy.org/ | `%LOCALAPPDATA%\Programs\ComfyUI\Comfy Desktop.exe` |
| cua-driver | (a Hermes része) | — | `hermes computer-use` |
| Ambient Widget | — | (a TUI beépített része) | nincs külön telepítés |

## 5. Egyéb programok, amik a TUI-hoz kellenek

| Program | Verzió | Netes elérés | Telepítési útvonal |
|---|---|---|---|
| Python | 3.13.x | https://www.python.org/downloads/ | `%LOCALAPPDATA%\Programs\Python\Python313\` |
| Node.js | 20+ (26.x tesztelve) | https://nodejs.org/ | `C:\Program Files\nodejs\` |
| hermes-agent | 0.20.3 | (pip) | `%LOCALAPPDATA%\hermes\hermes-agent` (editable) |
| Blender | 5.2 | https://www.blender.org/ | `C:\Program Files\Blender Foundation\Blender 5.2\blender.exe` |
| WSL (Ubuntu) | — | https://learn.microsoft.com/windows/wsl/ | a Windows része |
| Git | 2.55.x | https://git-scm.com/ | (csak fejlesztéshez kell) |

## 6. Ami a célgépen kell (a pendrive-csomaghoz)

1. Python 3.13.x (64-bit) — https://www.python.org/downloads/
2. Node.js 20+ — https://nodejs.org/
3. `python -m pip install hermes-agent==0.20.3`
4. A pendrive `telepites.bat` futtatása
5. A Utilities menü programjai (Thunderbird, AIMP, tldraw, ComfyUI) — a fenti
   netes elérésekről telepíthetők; nélkülük a menüpontok "program nem
   található" hibát adnak

---

### A build-módosítás (a fejlesztéshez kell, a csomag nem)

A `ui-tui/scripts/build.mjs`-ben az ssh2 `external: ['ssh2']` — ezért a
buildelt `entry.js` nem tartalmazza az ssh2-t (`grep -c poly1305
dist/entry.js` → 0), és futáskor a bundle MELLETTI `node_modules\ssh2`-t
tölti CJS-ként (a `__dirname` és a WASM működik). A fork-ból (`npm start`)
a node a gyökér `node_modules\ssh2`-t használja — a buildelt változatban a
pendrive telepítő teszi a node_modules-t az entry.js mellé.

### Környezet (2026-08-17, a frissítés után)

- A hermes Python 3.13-ra váltott; a régi 3.11-es `hermes-agent\venv`
  kiürült és törölve lett, a PATH-ból kivéve.
- Ha a TUI "gateway exited" hibát ír: a `python` parancs nem a 3.13-ra
  mutat (lásd az OLVASD_EL.txt hibaelhárítását).

---
*Készült: 2026-08-17. A csomag verziója: 3.0 (hermes-agent 0.20.3).*
