# Hermes TUI — Súgó (Péter fork)

Ez a Hermes terminál felület (TUI) személyre szabott változata. Az alábbiakban
mindent megtalálsz, ami a napi használathoz kell. A műszaki részletek
(Hermesnek szóló térkép) a `hermes/` mappában vannak.

---

## Billentyűparancsok

| Billentyű | Mit csinál |
|---|---|
| **F1** | Súgó (ez a fájl) |
| **F2** | Modell váltás (Kedvencek) |
| **F3** | Cron jobok |
| **F4** | Memtest — memória & kontext ellenőrzés (fact_store írás/olvasás/törlés teszt, MEMORY.md/USER.md töltöttség, beszélgetés mentés állapota; **r** = újrateszt; a Skills központ a Hermes menü → /skills alatt maradt) |
| **F5** | Session picker |
| **F6** | Plugins |
| **F7** | Tools |
| **F8** | Email (Thunderbird + MCP, automatikus) |
| **F9** | AIMP indítása |
| **F10** | Kontextusfüggő: fő nézetben kilépés, fájlkezelőben vissza a Hermes-be, belső szerkesztőben vissza a fájlkezelőbe |
| **Tab** | DN overlay: panel váltás |
| **Ctrl+X** | Session picker |
| **Ctrl+Shift+V** | Vágólap lista — a rendszer vágólapjának előzményei (kép, szöveg, fájlok) |
| **Ctrl+C** | Másolás (ha van kijelölés) / interrupt (ha AI válaszol) — NEM lép ki |
| **Egér** | Menük, kattintás, görgetés támogatott |

> Megjegyzés: Ctrl+C sosem törli a beviteli mezőt és nem lép ki — arra F10 van.

---

## Felső menüsor

**File**
- New session — új beszélgetés
- TUI frissítés / config update / pip update — frissítési infók
- **Köszönet az alkotóknak** — a Nous Research csapat névsora
- **Vágólap...** (Ctrl+Shift+V) — a rendszer vágólapjának ELŐZMÉNYEI +
  beillesztés: szöveg, kép, fájllista. Max 50 elem (körpuffer), 📌 pin (a
  kitűzött nem esik ki), Del = törlés, R = „Rögzítés most" (a JELENLEGI
  vágólap betétele — figyelés nincs, csak az kerül ide, amit te rögzítesz;
  tárolás: AppData\Local\hermes\dn_clipboard\history.json + img\). A felső
  menüsor a DN-ben is ugyanaz → a fájlkezelőből is elérhető (2026-08-24, a
  24 pontos terv 26. pontja). **Ctrl+C** = a kijelölt sor TELJES tartalmának
  másolása a vágólapra (a TUI alatt egérrel nem lehet szöveget kijelölni —
  ez a kimásolás módja), **V** = a rögzített kép megnyitása a Windows
  képnézőben. A New tab menüpont ELTÁVOLÍTVA (félrevezető volt — tab-infra
  nincs, session-váltás: F5 a session pickerben).
- **Súgó** — ez a fájl (kedvenc MD olvasóban nyílik)
- Parancsok — gyors parancs lista
- Exit — kilépés

**Hermes**
- /skills — skill kezelés (keresés, telepítés, törlés)
- /model — modell váltás (F2)
- /profil — Profilkezelő
- /cron — időzített feladatok
- /plugins — plugin központ
- /tools — eszközök
- /session — session kezelés (lista, váltás)
- ───────────
- 🔐 **Fájl lezárás (jelszó)** — a config.yaml / .env / auth.json védelme a
  TUI-ból: zárás és feloldás jelszóval, **UAC nélkül** (2026-08-21).
  Első használatkor jelszót kér (ugyanaz, mint a hermes_freeze.ps1),
  utána Enter = Lezárás / Feloldás. Az ADMIN-ZÁR fájlokat (GUI védelem)
  csak a hermes_unfreeze.ps1 oldja.

**Manager**
- FP — Fájlkezelő (DOS Navigator stílusú duál panel)
- FP — feladat szerkesztett fájljai ([FP] jelzés a menüsorban)
- Change drive (Alt-C) — lemezek + WSL + SFTP
- **Kijelölés ▸** — Select group (maszk, pl. *.txt), Mindent kijelöl (Ctrl+A), Kijelölés törlése (Esc)
- **Vágólapra ▸** — nevek / teljes útvonal / aktuális fájl a Windows vágólapra
- **Rendezés ▸** — Név / Méret / Dátum szerint (a panel fejlécére kattintva irány is váltható)
- DN fájlműveletek (F5 másolás, F6 áthelyezés, F7 új mappa, F8 törlés, F3 nézet, F4 szerkesztés, Csoportos átnevezés Ctrl+M, Frissítés)
- Profilkezelő
- Hermes & PC eszközök

> A Kijelölés / Vágólapra / Rendezés / DN-műveletek csak a DN fájlkezelőben
> (FP) aktívak — Hermes módban szürkén látszanak, de nem kattinthatók.

**Utilities (Eszközök)**
- **Thunderbird** (F8) — email workflow (fix script + MCP reload + kérdés)
- **AIMP** (F9) — zenelejátszó indítás
- **tldraw offline** — rajzolás (a tldraw offline API-jával)
- **ComfyUI (AI képgenerálás)** — képgenerátor indítás
- **Hermes & PC** — cua-driver indítás / állapot (computer use)
- **Ambient Widget rendszer** — widgetek indítása, listázása

**Panel**
- Panel beállítások (bal/jobb) — fejlesztés alatt
- Panel csere (swap) — fejlesztés alatt
- Minden ablak bezárása (Esc)

**Options**
- Hermes beállítások — a config.yaml útvonala, `hermes config set`
- Megjelenés (skin) — téma váltás

**Window**
- Teljes képernyő (Alt+Enter) / Normál nézet / Maximalizálás (Win+↑) / Visszaállítás (Win+↓)

---

## DN fájlkezelő (DOS Navigator stílus)

A **Manager → FP** menüvel (vagy F4-gyel a fájlok közt) nyitható duál panel
fájlkezelő.

| Billentyű | Művelet |
|---|---|
| **Tab** | Panel váltás (bal/jobb) — **Összehasonlítás módban: ugrás a következő ELTÉRÉSRE** (Shift+Tab = az előzőre) |
| **Shift+↑/↓** | Többes kijelölés (megjelölés + léptetés; Ins is működik) |
| **Ctrl+A** | Mindent kijelöl |
| **Ctrl+B** | **Flat nézet** be/ki — az AKTUÁLIS KÖNYVTÁR + almappái (8 szint mélyen) ÖSSZES fájlja egy listában, a fájlok mellett `[almappa]` jelzéssel. NEM a meghajtó! Enter = a fájl nézete, **Backspace = vissza a normál nézetbe** (a könyvtár marad) |
| **Esc** | Kijelölés törlése (csak utána zárja be a panelt) |
| **Alt+← / Alt+→** | Könyvtár-előzmények: vissza / előre (a látogatott mappák közt) |
| **Alt-F7** | **Keresés** — maszk dialógus (pl. `*.txt`), REKURZÍV keresés az aktív panel könyvtárában (minden almappában, 12 szint mélyen); a találati listában Enter = ugrás a fájlhoz + kijelölés |
| **Ctrl+D** | **Quick dirs** — kedvenc mappák, egy gombos ugrás; az első sor az aktuális mappa hozzáadása (+), Enter = ugrás/hozzáadás, Del = törlés. A lista megmarad újraindítás után is |
| **Ctrl+F1 / Ctrl+F2** | **Panel elrejtés** — a bal (Ctrl+F1) vagy jobb (Ctrl+F2) panel ki/be; a maradék panel TELJES szélességben megnyílik. Tab-bal csak a láthatóra lehet váltani |
| **Ctrl+P** | **Panel elrejtés** — az INAKTÍV panel ki/be (a másik, mint az aktív) |
| **Ctrl+O** | **Összehasonlítás (Compare)** be/ki — a két panel mappáinak összevetése; a jelek jelentését lásd lentebb |
| **Alt+S** | **Mappaszinkron** — a két mappa eltéréseinek átmásolása a másik panelre (irányválasztó dialógus) |
| **F3** | Nézet — **belső néző** (kódolásváltással, hex nézettel); a menüben **M = „Mindig ezzel"** (a kiválasztott program megjegyzése F3-ra — újraindítás után is) |
| **F4** | Szerkesztő menü (Belső szerkesztő, Notepad, nano, gedit, mcedit, Notepad++, VS Code...); a menüben **M = „Mindig ezzel"** (a kiválasztott program megjegyzése F4-re — újraindítás után is) |
| **F5** | Másolás a másik panelre |
| **F6** | Áthelyezés (azonos könyvtárban: átnevezés) |
| **F7** | Új mappa |
| **F8** | Törlés a Lomtárba (nem végleges!) |
| **F10** | Vissza a Hermes fő nézetébe (a teljes kilépés csak onnan van) |
| **Jobb gomb** | Kontext menü |
| **┌ / ┐** | Oszlopok: Név, Méret, Dátum, Leírás |

**Menüből (Manager):** Change drive... (Alt-C) — meghajtó/SFTP választó,
Quick dirs (Ctrl+D) — kedvenc mappák, Keresés... (Alt-F7) — rekurzív
maszkos keresés, **Összehasonlítás (Compare, Ctrl+O)** — a két panel
összevetése, **Fájlok diff (Alt+D)**, **Mappaszinkron... (Alt+S)**.
(A fájlműveletek a **Panel → Fájlműveletek ▸** alatt vannak.)

**Menüből (Panel):** Panel nézet ▸ (Normál / Flat / Fájlszűrő),
**Keresés ▸** (a bal panelen / a jobb panelen / **mindkét panelen** —
a találati listában [L]/[J] jelzi a találat oldalát), Rendezés ▸,
**Panel elrejtés ▸** (bal Ctrl+F1 / jobb Ctrl+F2 / inaktív Ctrl+P),
**Fájlműveletek ▸** — Kijelölés ▸ (Select group maszk / mindent / törlés),
Vágólapra ▸ (nevek / útvonallal / aktuális fájl), Másolás a másik panelre
(F5), Áthelyezés (F6), Átnevezés..., Csoportos átnevezés... (Ctrl+M),
Új mappa... (F7), Törlés (Lomtárba) (F8), Nézet (F3), Szerkesztés (F4),
Frissítés.

### Összehasonlítás (Compare) — a jelek jelentése

A **Ctrl+O** (vagy Manager → Összehasonlítás) a BAL és JOBB panel mappáját
veti össze név szerint. Minden fájl elé **jel** kerül a listában:

| Jel | Jelentés |
|---|---|
| `[=]` (zöld) | Mindkét oldalon megvan, **azonos** méret és dátum |
| `[≠]` (sárga) | Mindkét oldalon megvan, de **ELTÉR** (más méret vagy újabb/öregebb) |
| `[<]` (piros) | **Csak a bal panelben** van (a jobból hiányzik) |
| `[>]` (piros) | **Csak a jobb panelben** van (a balból hiányzik) |

A fejlécben ilyenkor **[CMP]** jelzés látszik. A FAR hagyománya szerint a
Compare **MEGJELÖLI** a csak-az-egyik-oldalon lévő és az **újabb** fájlokat —
utána egy mozdulattal dolgozhatsz rajtuk:

- **F5** = a megjelöltek átmásolása a másik panelre (pl. minden, ami a
  pendrive-on újabb vagy hiányzik → átmegy a gépbe — így szinkronizálsz)
- **F8** = a megjelöltek törlése
- **Tab / Shift+Tab** = ugrás a következő / előző eltérésre
- **Esc** = a megjelölés törlése, **Ctrl+O** = a Compare kikapcsolása

Megjegyzések:
- A könyvtárakat NEM hasonlítja (csak a fájlokat) — a mappák közt úgyis
  navigálsz.
- SFTP-s panelnél a DÁTUM megbízhatatlan (a szerver ideje), ezért ott csak a
  MÉRET számít — az azonos méretű fájlok `[=]`-t kapnak.
- A `[≠]` nem mondja meg, melyik az újabb — a megjelölés mutatja: az a fájl
  jelölődik meg, amelyik **frissebb** (azt kell átmásolni a frissítéshez).

### Fájlok diff (Alt+D / Compare + Enter)

Két fájl **TARTALMÁNAK** összehasonlítása (a 24 pontos terv 18. pontja):

- **Alt+D** — az AKTÍV panel kurzorán lévő fájl + a MÁSIK panel kurzorán
  lévő fájl (bármilyen név)
- **Compare módban Enter egy `[≠]` fájlon** — a két panel AZONOS NEVŰ,
  eltérő fájljainak összehasonlítása (a leggyorsabb út: Ctrl+O → Tab az
  eltérésre → Enter)
- **Manager → Fájlok diff (Alt+D)** — ugyanaz, mint az Alt+D

A diff ablak (a panelek felett, teljes képernyőn):

| Billentyű | Művelet |
|---|---|
| **Tab / Shift+Tab** | ugrás a következő / előző ELTÉRÉSRE |
| **↑/↓, PgUp/PgDn, Home/End** | görgetés (a két hasáb együtt) |
| **F10 vagy Esc** | vissza a fájlkezelőbe |

- **Két hasáb**: bal = a bal oldali fájl, jobb = a jobb oldali — a fejléc
  mutatja a TELJES útvonalakat
- **Színek**: fehér = azonos sor, **piros** = csak a bal oldalon van
  (törölt), **zöld** = csak a jobb oldalon van (új)
- A kódolás automatikus: UTF-8, ha érvényes — különben Windows-1250
- **Bináris fájl (kép, exe, zip...): HEX mód** — ha bármelyik oldal
  binárisnak tűnik (NUL byte vagy vezérlő-tömeg), MINDKÉT oldal hex
  dumpként jelenik meg (`[HEX]` jelzés a státuszban) — így a kép ↔ szöveg
  is összehasonlítható byte-szinten
- SFTP-nél NEM működik (a diff csak helyi fájlokra vonatkozik)
- A `[<]` / `[>]` (csak-az-egyik-oldali) fájlokon nincs diff — azoknak
  nincs párja a másik panelen

### Mappaszinkron (Alt+S / Manager → Mappaszinkron)

A **17. pont** — a két mappa összehangolása EGY mozdulattal, a Compare
(CTRL+O) térképére építve. Az **Alt+S** (vagy Manager → Mappaszinkron...)
kiszámolja az eltéréseket, és megkérdezi, **melyik irányba** másoljon:

| Választás | Mit csinál |
|---|---|
| **Bal → Jobb** | a balon lévő, jobbról hiányzó vagy ott RÉGEBBI fájlok átmásolása jobbra |
| **Jobb → Bal** | a jobbon lévő, balról hiányzó vagy ott régebbi fájlok átmásolása balra |
| **Kétirányú** | mindkettő — **a frissebb verzió nyer** (pl. pendrive ↔ gép) |

A dialógus a darabszámokat is mutatja. Futtatáskor a Compare BEKAPCSOL,
hogy a jelek (`[≠]` `[<]` `[>]`) és a megjelölés után látszódjon, mi
történt; a státuszsor összegzi az átmásolt fájlokat.

Megjegyzések:
- A diff-nél (mindkét oldalon megvan, eltér) a **frissebb** verzió megy át
  és **felülírja** a régebbit — ez a szinkron lényege (az F5-tel szemben,
  ami sosem ír felül)
- **NEM töröl** semmit — a csak-az-egyik-oldalon lévő fájl átmásolódik a
  másikra, az eredeti marad. A törlést a Compare megjelölésével + F8-cal
  teheted (az a te döntésed)
- Csak a FÁJLOKAT szinkronizálja a felső szinten (a könyvtárakat nem) —
  a Compare is így dolgozik
- SFTP-nél nem működik (csak helyi mappák)

### Becsomagolás / Kicsomagolás (7-Zip)

A **19. pont** — a 7-Zip-et használja. A 7z-t a legtöbben a **ninite.com**-ról
telepítik → az elsődleges hely a `C:\Program Files\7-Zip\7z.exe`; ha az nincs,
a PATH-ból vagy a `C:\tmp\tools` portable-ból veszi (a portable-nak a
**7z.dll** is kell az exe mellé!).

| Billentyű | Művelet |
|---|---|
| **Alt+F5** | **Becsomagolás** — a kijelölt (Ins) fájlokból archívum a MÁSIK panelre; a név kiterjesztése dönti a formátumot (`.7z` `.zip` `.tar` `.gz` `.bz2` `.xz` — alap: 7z). Ha nincs megjelölés, a kurzor alatti fájl megy |
| **Alt+F9** | **Kicsomagolás** — a kurzor alatti archívum kibontása (a dialógusban módosítható a cél; Enter = a másik panel) |
| Jobb gomb → **Archívum teszt (7z t)** | sértetlen-e az archívum (a Panel → Fájlműveletek menüből is) |

Megjegyzések:
- A **már létező archívumot NEM írja felül** (biztonság)
- SFTP-nél nem működik (a 7z helyi program)
- A tömörítés a 7z alapbeállításával megy (7z: LZMA2, zip: Deflate)
- Panel → Fájlműveletek ▸ menüből is elérhető

## Belső néző / szerkesztő (kódolásváltás)

Az **F3** mostantól a belső nézőt nyitja (a külső programok az F4 menüből
érhetők el: „Belső szerkesztő" + Notepad, nano, VS Code...). A belső ablak a
két panel felett, DN stílusban:

- **Kék címsor**: `DN/2: Edit - C:\tmp\fájl` + óra
- **Kék menüsor**: File · Edit · Search · Paragraph · Block · Misc · Options
  (Tab-bal lépsz rá, ←/→ vált, Enter = almenü, Esc = vissza; egérrel is)
- **Kódolásváltás az F-sorral** (az alsó gombsor ilyenkor a szerkesztőét
  mutatja — 3 rétegű: Hermes fő nézet / DN fájlkezelő / belső szerkesztő):
  F2 = CP 437 · F3 = CP 850 · F4 = CP 852 (magyar DOS) · F5 = ISO 8859-2 ·
  F6 = Windows 1250 · F7 = UTF-8 · F8 = Hex nézet · F9 = következő (CP 866,
  KOI8-R) · **F10 = Vissza a fájlkezelőbe** (minden fókuszból — a kék
  menüből is; az Esc is előbb ide visz)
- **Szerkesztő (F4 → Belső szerkesztő)**: a kurzorral írsz (↑↓←→, Backspace,
  Enter = új sor), **Ctrl+S vagy File → Mentés** ment az aktív kódolásban
- **Keresés**: **Ctrl+F** vagy a kék menü Search → gépeld be, Enter = ugrás,
  Esc = kilép
- A státuszsor mutatja: kódolás, sor:oszlop, módosítva jelzés

---

## Vágólap lista — használat (26. pont)

A **File menü → Vágólap...** (vagy **Ctrl+Shift+V**) a rendszer vágólapjának
ELŐZMÉNYEIT listázza: szövegek, képek, fájllisták vegyesen (📄 / 🖼 / 📁).
Tárolás: `AppData\Local\hermes\dn_clipboard\history.json` + `img\`.

**Fontos: a lista csak KÖZBENSŐ tároló — a ki- és bevitel mindig a Windows
vágólapján keresztül megy.**

| Billentyű | Művelet |
|---|---|
| **R** | **Rögzítés most** — a JELENLEGI vágólap tartalma bekerül a listába (szöveg → kép → fájllista sorrendben, ami épp ott van). Figyelés NINCS: csak az kerül ide, amit te rögzítesz |
| **↑/↓** | navigálás a listában (PgUp/PgDn = 8-cal) |
| **Enter** | a kijelölt elem a vágólapra (szöveg = a TELJES szöveg, kép = a kép, fájlok = a fájllista) + az elem ELŐRE kerül |
| **Ctrl+C** | ugyanaz, mint az Enter, de a lista sorrendje NEM változik |
| **V** | 🖼 képen: a kép megnyitása a Windows képnézőben (hogy lásd, mit rögzítettél) |
| **P** | 📌 pin — a kitűzött elem nem esik ki a 50-es körpufferből |
| **Del** | törlés a listából (képnél a PNG fájl is) |
| **Esc / q** | bezárás |

**Példa — egy régebbi szöveg beillesztése a Hermesbe:**
1. File menü → Vágólap... (vagy Ctrl+Shift+V)
2. ↓ — állj a kívánt sorra
3. **Ctrl+C** (vagy Enter) — a teljes szöveg a vágólapra kerül
4. **Esc** — lista bezárása
5. A Hermes beviteli mezőjében **Ctrl+V** (vagy jobb gomb → Beillesztés)

Ugyanígy MÁSHOVA is: a vágólapra tett elem beilleszthető Wordbe, böngészőbe,
jegyzettömbbe... A 🖼 sor Ctrl+C/Enter után a KÉP a vágólapon van — pl.
Wordbe vagy chatbe Ctrl+V-vel illeszthető.

> Megjegyzés: a TUI alatt az EGÉRREL nem lehet szöveget kijelölni (a TUI
> elfogja az egeret) — ezért van a lista-beli Ctrl+C. A Ctrl+Shift+V-t a
> Windows Terminal alapból elkapja beillesztésnek; ha nem nyitja a listát,
> a File menüből nyitható (vagy a WT settings-ben átírható).

WSL útvonalak: `/mnt/c/...` — figyelj a perjelre a drive betű után!

---

## Rendszerinfó ablak (app-nézetek 1. jelöltje)

A **Ctrl+I** (vagy **Utilities → Hermes & PC → Rendszerinfó**) TELJES
KÉPERNYŐS ablakot nyit a gép adataival: **Hermes** + **Windows** + **WSL**
szekció (minden telepített Linux distró — pl. Ubuntu, kali-linux). A
szélessége a teljes terminál (mint a fájlkezelő két panelje együtt).

| Billentyű | Művelet |
|---|---|
| **← / →** | állapot-gombok váltása (LAN / WiFi / BT / Akku — a kijelölt részlete a cím alatt) |
| **R** | frissítés (a cache átugrása — a WSL VM-ek újra lekérdezve) |
| **↑ / ↓ / j / k** | görgetés soronként |
| **PgUp / PgDn / b / Szóköz** | lapozás |
| **g / G** | az elejére / a végére |
| **Esc / q** | bezárás |

**Jobb felső sarok — 4 állapot-gomb:** `LAN` `WiFi` `BT` `Akku` — a szín
mutatja az állapotot (zöld = aktív, piros = inaktív, szürke = még nincs adat),
a ←→-vel kiválasztott gomb részlete a cím alatt látszik (pl. „WiFi:
sc-E20B60 2 · 1.2 Gbps", „Akku: 81% · töltés alatt", a BT-nél a csatlakoztatott
eszközök).

**Hermes szekció:** verzió + kiadás dátuma, az aktív modell/provider.

**Windows szekció:** gépnév, Windows verzió + build, arch, CPU (mag/szál),
RAM (használati sávval), diszkek (C: stb. — méret + szabad), uptime, node és
python verzió. PowerShell-lel kérdezi le, cache 10 mp.

**WSL szekció:** minden telepített distróhoz a `uname -a; free -h; df -h /;
uptime` kimenete. A lekérdezés lassú lehet (a VM-ek indítása), ezért a válasz
**cache-elve** (60 mp, a TUI életéig) — a második megnyitás már azonnali.
A docker-desktop (nem valódi Linux) NEM szerepel. Ha egy distró nem indul,
a saját sorában hibaüzenet — semmi nem fagy le.

> Tipp: ha első megnyitáskor lassúnak tűnik, az a VM-indítás; R-rel frissítve
> már cache-ből jön. Ha a tartalom hosszabb a képernyőnél, a görgető
> billentyűkkel lapozható (a hint mutatja az aktuális pozíciót).

## Kis eszközök — Számológép / Naptár / ASCII (8. pont)

A **Utilities → Hermes & PC → Kis eszközök** menü TELJES KÉPERNYŐS ablakot
nyit 3 nézettel — a **Tab** billentyű vált közöttük:

| Billentyű | Művelet |
|---|---|
| **Tab** | következő nézet (Számológép → Naptár → ASCII) |
| **Esc / q** | bezárás |

**Számológép:** billentyűzetes alapműveletek — `0-9` számok, `.` vagy `,`
tizedes, `+ − * /` műveletek, **Enter** = egyenlő, **Backspace** ⌫ törlés,
`c` = mindent töröl, `%` = százalék, `n` = előjelváltás. A művelet
láncolható (2 + 3 × 4 = 20, balról jobbra). Hibánál (pl. nullával osztás)
„Hiba" jelenik meg — `c`-vel lehet kilépni belőle.

**Naptár:** hónapnézet hétfő-kezdéssel, magyar napnevekkel — **← / →**
hónapváltás, **↑ / ↓** évváltás, **t** = vissza a mai napra (a mai nap
kiemelve, a hétvége színezve).

**ASCII tábla:** a kinyomtatható karakterek (32–126) dec + hex + karakter
jelöléssel (a szóköz ␣), görgethető (↑↓/jk, PgUp/PgDn, g/G), alul a magyar
ékezetesek U+ kóddal (fájlnevekhez/kódoláshoz).

## Fájlkódolás — Base64 (23. pont)

A DN fájlkezelő **kontext menüjéből** (jobb egérgombbal a fájlon) →
**„Kódolás (Base64)..."** — a kijelölt FÁJLRA (nem mappára). A dialógus 3
irányt kínál:

| Opció | Mit csinál |
|---|---|
| **Kódolás** | `fájl → fájl.b64` a **másik panelre** (a base64 szöveges fájlba írva) |
| **Base64 a vágólapra** | a base64 a Windows vágólapra (csak ≤ 512 KB fájlnál; nagyobbnál szürke) |
| **Dekódolás** | `fájl.b64 → fájl` a **másik panelre** (a `.b64` levágva, az eredeti névvel) |

- A cél **soha nem íródik felül** („Már létezik a célban" hiba).
- Érvénytelen base64 tartalom → hibaüzenet, nem ír szemétdombot.
- SFTP-nél nem támogatott (csak helyi fájlok).
- Használat: kódolás pl. bináris fájl emailben/csevegésben; dekódolás
  visszaállításhoz. A `.b64` fájl sima szöveg — bárhova másolható.

## Gyorsfeljegyzés — a fájlok leírása (22. pont)

A DN panelben a fájl melletti **Desc oszlop** mutatja a fájl leírását
(gyorsfeljegyzés). Szerkesztés: **Ctrl+Z** a kijelölt fájlon, vagy a
**kontext menü → „Gyorsfeljegyzés..."**. A leírás a **`descript.ion`**
fájlba kerül a mappában — **ugyanabban a formátumban, amit a Total
Commander használ** (`fájlnév=leírás`), így a két program megosztja egymás
feljegyzéseit.

- **Ctrl+Z** — a kijelölt fájl leírásának szerkesztése (a meglévő előtöltve)
- **Üres leírás** mentése = a bejegyzés törlése (ha minden törlődik, a
  descript.ion fájl is eltűnik)
- A Desc oszlop fix 18 karakter — a hosszabb leírás csonkolva látszik
  (a teljes a descript.ion-ban van)
- SFTP-nél nem támogatott (a descript.ion helyi fájl)

## Kijelölés mentése / visszaállítása (20. pont)

A megjelölt (Ins) fájlok listáját a DN a mappa **`kijeloles.lst`**
fájljába menti (a FAR/TC hagyománya — fájlnév soronként, UTF-8), és onnan
vissza is tölti. A **kontext menü** két pontja:

- **„Kijelölés mentése (kijeloles.lst)"** — a megjelölt nevek mentése
  (üres kijelölésnél hibaüzenet)
- **„Kijelölés visszaállítása (kijeloles.lst)"** — a listából csak a
  JELENLEGI mappában létező fájlok jelölődnek meg (a többit kihagyja)
- SFTP-nél nem támogatott (a .lst helyi fájl)

## WSL: Jogok (chmod) és szimbolikus link (21. pont)

A DN a WSL-distrókat a **Change drive**-ban éri el (`\\wsl.localhost\<distro>`).
Az ilyen útvonalon a kontext menü két EXTRA pontot kap:

- **„Jogok (chmod)..."** — a mód bekérése (pl. `755`, `644` — 3 vagy 4
  oktális jegy), majd `wsl.exe -d <distro> chmod <mód> <fájl>` fut le
- **„Szimbolikus link a másik panelre..."** — a link nevének bekérése,
  majd `wsl.exe ln -s` a kijelölt fájlra a másik panel mappájába
  (csak UGYANAZON a distrón belül — a két panelnek egy WSL-distrót kell
  néznie)
- A chmod fájlra és mappára is megy; a link bármelyikre létrehozható
- Helyi (nem WSL) útvonalon ezek a menüpontok nem jelennek meg

## VFS — archívum mint mappa (24. pont)

A DN a **TC/FAR mintáját** követi: egy archívumra (zip / 7z / rar / tar /
gz / bz2 / xz) **Enter** = belépés a tartalmába, mintha mappa lenne.

| Billentyű | Művelet a VFS-ben |
|---|---|
| **Enter** | mappába lépés az archívumon belül (a fájlra nincs nézet — előbb F5) |
| **Backspace / `..`** | kilépés (a belső mappa szülője; a gyökérnél a valódi mappa) |
| **F5** | a kijelölt belső fájl **kicsomagolása a másik panelre** (`7z e`) |
| **F3 / F4** | üzenet: a VFS-fájlt előbb ki kell másolni (F5), hogy nézhető legyen |

- A belső mappák és fájlok a `7z l -slt` listából jönnek (a 7-Zip kell
  hozzá — a becsomagolásnál megszokott helyekről)
- A másolásnál a szokásos cél-védelem él (a létező fájlt nem írja felül)
- SFTP-nél nem érhető el; a kicsomagolt fájl a célmappa gyökerébe kerül
  (a belső almappaszerkezet nélkül — a `7z e` laposan csomagol ki)

---

## SFTP — kapcsolódás távoli szerverhez

A fájlkezelő a **Change drive**-ból (Alt-C) SFTP-n keresztül eléri a távoli
Linux szervereket (Ubuntu openssh-server — a leggyakoribb SSH-szerver, az
SFTP benne van).

**Kapcsolódás:**
1. **Alt-C** (Change drive) → a lista végén: **SFTP...**
2. **Enter** → beírod: `felhasználó@cím` (pl. `user@192.168.1.50`)
   - Ha más port kell: `felhasználó@cím:2222` (alap: 22)
3. **Jelszó** → Enter → a panel a szerver fájljait mutatja
   - Enter = mappába lépés, Backspace = feljebb (a gyökérnél megáll)

**WSL-teszt (helyi próba):** a WSL Ubuntu-ba `user@<IP>`-vel lépsz be,
ahol az IP-t a `wsl hostname -I` parancs írja ki (a WSL újraindulásakor
**változhat**). A `localhost` jelenleg nem megy (Windows forwarding hiba).

**Tudni érdemes:**
- A jelszó **nem marad meg** — minden kapcsolódásnál újra bekéri (biztonságos)
- Hibaüzenetek: „kapcsolat elutasítva" (nincs SSH a címen), „időtúllépés —
  tűzfal blokkolja?" (a tűzfalban engedélyezni kell a kimenő SSH-t),
  „ismeretlen cím" (elgépelted)
- A kapcsolat után a drive bar-ban **SFTP felhasználó@cím** jelenik meg —
  arra kattintva visszalépsz a szerver gyökerére

**Letöltés / feltöltés (F5):** ha az egyik panel SFTP-n van, a másik helyi:
- **F5** a szerver oldalán → **letöltés** (a szerver fájlja a helyi panelre)
- **F5** a helyi oldalon → **feltöltés** (a helyi fájl a szerverre)
- Ha a célban már van ilyen nevű fájl, **nem írja felül** — hibaüzenetet ad
- Megjelöléssel (Ins) egyszerre több fájl is megy
- Az F5 gomb felirata mutatja, mit csinál: Letöltés / Feltöltés / Másolás

---

## Widgetek (jobb oldali panel)

- **/sidepanel** — óra + todo + Hermes info
- **/ticker** — tőzsde sparkline
- **/weather** — időjárás
- Aktív widgetek: Eszközök menüből listázhatók, kapcsolhatók

---

## Profilok

A **Manager → Profilkezelő** menüben:
- ↑↓ navigáció, Enter = váltás, `d` = törlés (2× megerősítés)
- Tab = almenü (modell, munkakönyvtár)
- A váltás a TUI újraindítása után lép életbe
- A `default` profil nem törölhető

Profilok: `default`, `tui`, `hazi-feladat`, `qwenticoo`.

---

## Gyakori parancsok

```
/model        - Modell váltás
/model-fav    - Kedvenc modellek (F2)
/skills       - Skill kezelés
/cron         - Cron jobok
/sessions     - Session picker
/new          - Új session
/resume last  - Legutóbbi session folytatása
/tools        - Tool lista
/plugins      - Plugin kezelés
/sidepanel    - Jobb oldali panel
/help         - Súgó
```

---

## Tippek

- **F8 email**: automatikusan elindítja a Thunderbird MCP-t, megjavítja a
  permission mappát, és beírja a "Mennyi email érkezett?" kérdést.
- **F9 AIMP**: zenelejátszó indítás egy gombbal.
- **F10**: a teljes kilépés CSAK a Hermes fő nézetéből van — a fájlkezelőben visszalép a Hermes-be, a belső szerkesztőben a fájlkezelőbe. Ctrl+C, Ctrl+D nem lép ki.
- A TUI a forrásból indul (`npm start`), így minden módosítás azonnal él.
- A menük útvonalai a felhasználónevet futásidőben kérik le — a TUI másik
  gépen is működik (a programoknak a szokásos helyen kell lenniük).
- Lassú válasz? F2-vel válts gyorsabb cloud modellre (gpt-oss:20b:cloud).

---

## Telepítés másik gépre (pendrive)

A `C:\tmp\pendrive2` csomag (2.0, 2026-08-14 — entry.js + ssh2 node_modules +
server.py + cua_backend.py + telepites.bat + OLVASD_EL.txt) a tiszta hermes
0.19.0 fölé telepíthető:
1. Python 3.13 + Node 20+ + `pip install hermes-agent==0.19.0`
2. `telepites.bat` futtatása (backup-pal felülírja a TUI fájljait: entry.js,
   node_modules/ssh2, server.py, cua_backend.py)
3. `hermes --tui` — az ssh2 a csomagban lévő node_modules-ből töltődik

A csomag leírásai a pendrive2 mappában: `OLVASD_EL.txt` (telepítési útmutató),
`hermes_modositasok_es_programok.md` (a fork változásai + programlista),
`f8_f9_workflow.md` (Thunderbird/AIMP), és a `tui_sugo/` (ez a Súgó).

> **Megjegyzés a verzióról:** a naprakész gép (fekec) már hermes **0.20.1**-t
> futtat (2026-08-13), de a pendrive-csomag a 0.19.0-hoz készült — a célgépen
> a telepítő a 0.19.0-t várja. Mindkét verzióra igaz, hogy a fork aktív.

---

*Utolsó frissítés: 2026-08-24*

> **Kész:** a DN-fájlkezelő 24 pontos bővítési listájából a **Flat nézet**
> (Ctrl+B, az összes almappa fájlai egy listában — Enter = nézet, Backspace =
> kilépés), a **Quick dirs** (Ctrl+D, kedvenc mappák — a lista megmarad
> újraindítás után is), a **Keresés** (Alt-F7, rekurzív maszkos keresés —
> a találatból Enter = ugrás a fájlhoz), a **„Mindig ezzel" editor**
> (az F3/F4 menüben M — a kiválasztott néző/szerkesztő megjegyzése, a default
> a lista elejére kerül [✓] jelzéssel, újraindítás után is megmarad), a
> **Fájlszűrő** (Alt-Del, pl. *.txt — a könyvtárak mindig látszanak,
> [SZŰRŐ:maszk] jelzés) és a **Panel elrejtés** (Ctrl+F1/F2/P — a maradék
> panel teljes szélességben) is elkészült (2026-08-18–20), így a "6 kedvenc"
> mind lezárva. A **Keresés** a Panel menübe is bekerült (bal/jobb/mindkét
> panel, [L]/[J] jelzéssel). 2026-08-24: a **Mappaszinkron** (Alt+S —
> a két mappa eltéréseinek átmásolása irányválasztóval) és a
> **Vágólap lista** (26. pont: File menü → Vágólap... / Ctrl+Shift+V,
> max 50 elem + pin, kép külön PNG-ként; a New tab menüpont törölve)
> is elkészült. A további tervezett pontok
> (mappa-összehasonlítás, VFS-archívum stb.) és a **kisablakos chat** ötlete
> a műszaki térképben: `hermes/08_hatralevo_terv.md`.

---

*FP lista teszt — 2026-08-06: ezt a sort a Hermes írta, hogy az FP gyűjtőt élőben teszteljük.*
