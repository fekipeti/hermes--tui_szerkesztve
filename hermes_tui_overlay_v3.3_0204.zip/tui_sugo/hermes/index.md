# Hermes TUI — Műszaki térkép (LLM-nek)

Ez a fájl a Hermes TUI Péter-forkjának teljes műszaki térképe. Cél: ha a
menüsor, overlay-ek vagy bármely bekötés elveszne (frissítés, új LLM, új
checkout), ebből a mappából **visszaépíthető** az egész. Minden szekció
önállóan olvasható — az index csak belépési pont.

## Fontos alapigazságok (rövid)

1. **A TUI két részből áll:** TypeScript frontend (`ui-tui/`, Ink/React) +
   Python gateway (`tui_gateway/`, JSON-RPC stdio felett). A TS spawn-olja a
   Pythont: `python -m tui_gateway.entry`, `PYTHONPATH=<forras-gyökér>`.
2. **Két indítási mód:**
   - `npm start` (ui-tui mappában) → **MINDEN a forrásból fut** (TS + Python).
     A site-packages-be másolás NEM kell. Fejlesztéshez ez a mód.
   - `hermes --tui` (telepített) → a site-packages-ből fut; a fork-módosítások
     csak akkor élnek, ha átmásoltuk őket (entry.js + tools/*.py + server.py).
3. **Forrás gyökér:** `C:\tmp\herm_tui\forras` (teljes Hermes repo).
4. **User config:** `C:\Users\fekec\AppData\Local\hermes\` (HERMES_HOME,
   default profil). Itt van a `help/` mappa is.
5. **Prompt caching szent:** ne mutálj múltbeli kontextust, ne cserélj
   toolset-et menet közben.

## Szekciók

| Fájl | Tartalom |
|---|---|
| [01_fajl_terkep.md](01_fajl_terkep.md) | ui-tui/src komponensek + tui_gateway fájlok, szerepkörökkel és méretekkel |
| [02_menu_bekotes.md](02_menu_bekotes.md) | MENUS tömb szerkezete, új menüpont/overlay bekötésének receptje, F-gombok, spawn használat |
| [03_overlayek_rpc.md](03_overlayek_rpc.md) | Overlay-ek listája + teljes RPC metódus katalógus (tui_gateway/server.py) |
| [04_build_deploy.md](04_build_deploy.md) | Build/teszt/deploy workflow: npm start, build, site-packages másolás, tesztek |
| [05_meretadatok.md](05_meretadatok.md) | Fájlméretek, sor-számok, verziók — a "mi a normális" referencia |
| [06_ui_szabalyok.md](06_ui_szabalyok.md) | Péter UI-preferenciái (kontraszt, méret, színek), amit betartani kell |
| [07_jellemzo_hibak_es_javitasuk.md](07_jellemzo_hibak_es_javitasuk.md) | **LLM/config hibakatalógus: a 13 ismert hiba + javításuk + a 4 profil config-térképe. Modell/config hiba esetén EZT olvasd először!** |
| [08_hatralevo_terv.md](08_hatralevo_terv.md) | **A hátralévő fejlesztési terv: a 24 pontos DN-terv teljes állapota (kész+hátra) + a kisablakos chat terv + computer use stabilitás + a kutatás. Új fejlesztési kör előtt EZT olvasd!** |
| [09_spec_fajlkezelo.md](09_spec_fajlkezelo.md) | **A DN fájlkezelő építési specifikációja: ablakméretek, layout, menük, és a 3 rétegű F1-F10 gombsor pontos gombnevei+feladatai (Hermes / fájlkezelő / belső szerkesztő). A fájlkezelő újraépítéséhez EZT olvasd!** |

## A Súgó rendszer maga

- `C:\Users\fekec\AppData\Local\hermes\help\sugo.md` — emberi Súgó, a
  menüsor **File → Súgó** pontja nyitja (`cmd /c start` → kedvenc MD olvasó).
- Ez a mappa (`hermes/`) — az LLM-nek szóló térkép. Nincs menüben, a path a
  Hermes memóriájában és az AGENTS.md hivatkozásaiban él.
- Ha a menüsor elveszne: lásd [02_menu_bekotes.md](02_menu_bekotes.md) —
  a Súgó menüpont bekötési mintája benne van.

## Karbantartás

- A `05_meretadatok.md` frissíthető scripttel:
  `wc -l <fájlok>` + `ls -la` — a pontos parancsok a fájl végén vannak.
- Ha új komponens/overlay/RPC születik, írd be a megfelelő szekcióba —
  a térkép csak akkor ér bármit, ha naprakész.
