# 05 — Méretadatok és verziók (2026-08-08)

A "mi a normális" referencia. Ha egy fájl hirtelen sokkal nagyobb/kisebb,
vagy hiányzik, itt ellenőrizhető.

## Verziók

| Komponens | Verzió |
|---|---|
| Hermes Agent | **0.20.1 (pip, 2026-08-13)** — a gép már ezt futtatja; a pendrive-csomag 0.19.0-hoz készült |
| Hermes (a csomag célverziója) | 0.19.0 (a pendrive2 OLVASD_EL + telepites.bat ehhez) |
| Python | 3.13 (AppData\Local\Programs\Python\Python313) — a legújabb build 3.13.15 |
| Node/tsx | package.json szerint (tsx ^4, ink ^6, react ^19); a gép Node 26.7.0 |
| **cua-driver** | **0.19.2** (2026-08-09 frissítve a 0.12.6-ról — a régi lefagyott; a pendrive2 hermes_modositasok is ezt írja) |

## ui-tui/src komponensek (sor-számok)

| Fájl | Sor |
|---|---|
| textInput.tsx | 1501 |
| appLayout.tsx | 2204 |
| thinking.tsx | 1246 |
| markdown.tsx | 1165 |
| subscriptionOverlay.tsx | 1024 |
| agentsOverlay.tsx | 976 |
| billingOverlay.tsx | 950 |
| activeSessionSwitcher.tsx | 917 |
| appChrome.tsx | 845 |
| menuBar.tsx | 1106 |
| modelPicker.tsx | 707 |
| journey.tsx | 595 |
| profileManagerOverlay.tsx | 581 |
| dnPanelOverlay.tsx | 790 |
| **dnInternalEditor.tsx** | **700** — a belső néző/szerkesztő (DN Encoding, 2026-08-12) |
| dnFileOps.ts | 652 |
| appOverlays.tsx | 468 |
| gridStreamsDemo.tsx | 364 |
| gridTestOverlay.tsx | 318 |
| prompts.tsx | 312 |
| skillsHub.tsx | 301 |
| messageLine.tsx | 276 |
| widgetGrid.tsx | 267 |
| modelFavorites.tsx | 263 |
| overlayPrimitives.tsx | 247 |
| pluginsHub.tsx | 241 |
| skillCreatorOverlay.tsx | 193 |
| petPicker.tsx | 187 |
| loaders.tsx | 172 |
| streamingMarkdown.tsx | 166 |
| overlay.tsx | 141 |
| fpList.tsx | 139 |
| skillDeleteOverlay.tsx | 132 |
| streamingAssistant.tsx | 118 |
| skillInstallOverlay.tsx | 96 |
| todoPanel.tsx | 93 |
| petSprite.tsx | 93 |
| overlayScrollbar.tsx | 84 |
| helpHint.tsx | 68 |
| queuedMessages.tsx | 64 |
| accordion.tsx | 58 |
| overlayControls.tsx | 50 |
| infoMenuOverlay.tsx | 44 |
| maskedPrompt.tsx | 41 |

## ui-tui/src gyökér

| Fájl | Sor |
|---|---|
| theme.ts | 944 |
| gatewayClient.ts | 794 |
| gatewayTypes.ts | 688 |
| types.ts | 229 |
| entry.tsx | 177 |
| banner.ts | 93 |
| app.tsx | 25 |

## ui-tui/src lib/hooks

| Fájl | Sor |
|---|---|
| lib/mathUnicode.ts | 783 |
| hooks/useVirtualHistory.ts | 554 |
| lib/widgetGrid.ts | 510 |
| lib/terminalSetup.ts | 444 |
| lib/externalLink.ts | 440 |
| lib/platform.ts | 414 |
| lib/text.ts | 368 |
| lib/dnSftp.ts | 356 |
| **lib/dnEncoding.ts** | **81** — a belső szerkesztő kódolási segédei (iconv-lite, CP437/850/852, ISO-8859-2, Win1250, UTF-8, hex, 2026-08-12) |
| lib/subagentTree.ts | 351 |
| lib/color.ts | 325 |

## tui_gateway (Python)

| Fájl | Sor |
|---|---|
| server.py | 17238 |
| compute_host.py | 768 |
| project_tree.py | 640 |
| host_supervisor.py | 568 |
| ws.py | 476 |
| entry.py | 434 |
| synthetic_turn.py | 231 |
| transport.py | 219 |
| git_probe.py | 183 |
| slash_worker.py | 179 |
| _stdin_recovery.py | 151 |
| event_publisher.py | 126 |
| loop_noise.py | 83 |
| render.py | 49 |

## Frissítő parancsok

```bash
# Komponensek sor-száma
wc -l C:/tmp/herm_tui/forras/ui-tui/src/components/*.tsx C:/tmp/herm_tui/forras/ui-tui/src/components/*.ts | sort -rn

# Gyökér
wc -l C:/tmp/herm_tui/forras/ui-tui/src/*.tsx C:/tmp/herm_tui/forras/ui-tui/src/*.ts | sort -rn

# tui_gateway
wc -l C:/tmp/herm_tui/forras/tui_gateway/*.py | sort -rn

# RPC metódusok
grep '@method("' C:/tmp/herm_tui/forras/tui_gateway/server.py | sed 's/.*@method("//;s/").*//' | sort | tr '\n' ' '

# Verziók
python -m pip index versions hermes-agent
```
