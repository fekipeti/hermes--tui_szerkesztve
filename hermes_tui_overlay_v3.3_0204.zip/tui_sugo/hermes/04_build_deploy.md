# 04 — Build / teszt / deploy workflow

## Két indítási mód

### 1. Fejlesztés: `npm start` (forrásból, MINDEN él)

```bash
cd C:\tmp\herm_tui\forras\ui-tui
npm start          # = tsx src/entry.tsx — TS a forrásból
```

- A TS frontend a `src/`-ből fut → minden módosítás azonnal él (újraindítás
  után; `npm run dev` = watch mód).
- A Python gateway-t a TS spawn-olja: `python -m tui_gateway.entry`,
  `PYTHONPATH = C:\tmp\herm_tui\forras` (a forrás gyökér az ELEJÉN) →
  **a teljes Python oldal is a forrásból fut** (tui_gateway, hermes_cli,
  tools, model_tools...).
- A python = Hermes Python313 (AppData\Local\Programs\Python\Python313),
  mert nincs .venv a forrásban; `resolvePython()` a PATH-ról veszi.
- **Site-packages-be másolás NEM kell ebben a módban.**

### 2. Telepített: `hermes --tui` (site-packages-ből)

```bash
hermes --tui
```

- A pip telepített buildből fut: `site-packages\hermes_cli\tui_dist\entry.js`
  + a site-packages Python moduljai.

> **FIGYELEM a gép aktuális állapotához (2026-08-14):** Péter gépen a hermes
> 0.20.1 mostantól saját venv-ből fut — `C:\Users\fekec\AppData\Local\hermes\
> hermes-agent` (a `which hermes` erre mutat, és ott van saját `ui-tui/dist/
> entry.js` + `hermes_cli`). A pendrive-csomag (0.19.0) receptje alább a
> 0.19.0-s site-packages-be való másolást írja le — a 0.20.1-gyel a fork
> aktualizálásához a megfelelő helyre kell másolni (a saját venv
> site-packages-ébe). Követés `hermes --version` + `which hermes`.
- **A fork-módosítások csak akkor élnek, ha átmásoltuk őket:**

```bash
# 1) TUI build + másolás
cd C:\tmp\herm_tui\forras\ui-tui
npm run build
cp dist/entry.js "C:\Users\fekec\AppData\Local\Programs\Python\Python313\Lib\site-packages\hermes_cli\tui_dist\entry.js"

# 1b) ssh2 + függőségek (az entry.js external ssh2-vel készül — a node
#     futásidőben a tui_dist\node_modules-ből tölti; enélkül az SFTP
#     __dirname hibával meghal)
cp -r "C:\tmp\herm_tui\forras\node_modules\ssh2"          "C:\Users\fekec\AppData\Local\Programs\Python\Python313\Lib\site-packages\hermes_cli\tui_dist\node_modules\"
cp -r "C:\tmp\herm_tui\forras\node_modules\asn1"          "C:\Users\fekec\AppData\Local\Programs\Python\Python313\Lib\site-packages\hermes_cli\tui_dist\node_modules\"
cp -r "C:\tmp\herm_tui\forras\node_modules\bcrypt-pbkdf"  "C:\Users\fekec\AppData\Local\Programs\Python\Python313\Lib\site-packages\hermes_cli\tui_dist\node_modules\"
cp -r "C:\tmp\herm_tui\forras\node_modules\safer-buffer"  "C:\Users\fekec\AppData\Local\Programs\Python\Python313\Lib\site-packages\hermes_cli\tui_dist\node_modules\"
cp -r "C:\tmp\herm_tui\forras\node_modules\tweetnacl"     "C:\Users\fekec\AppData\Local\Programs\Python\Python313\Lib\site-packages\hermes_cli\tui_dist\node_modules\"

# 2) Python módosítások (pl. tools/computer_use)
cp -r "C:\tmp\herm_tui\forras\tools\computer_use" "C:\Users\fekec\AppData\Local\Programs\Python\Python313\Lib\site-packages\tools\"

# 3) tui_gateway/server.py (ha Model Favorites vagy más fork-szekció kell)
cp "C:\tmp\herm_tui\forras\tui_gateway\server.py" "C:\Users\fekec\AppData\Local\Programs\Python\Python313\Lib\site-packages\tui_gateway\server.py"
```

- A gateway Python cache-eli a modulokat → **TUI újraindítás kell** a Python
  oldali változáshoz.

## Parancsok (ui-tui mappában)

| Parancs | Mit csinál |
|---|---|
| `npm start` | Futtatás forrásból (tsx) |
| `npm run dev` | Watch mód (build:ink + tsx --watch) |
| `npm run build` | Teljes build (hermes-ink + tsc) → `dist/entry.js` |
| `npm run typecheck` | Csak típusellenőrzés (tsc --noEmit) |
| `npm run lint` | ESLint |
| `npm run fmt` | Prettier formázás |
| `npm test` | Vitest tesztek |
| `npm run check` | build:ink + typecheck + test |

## Tesztek

- TS: `npm test` (vitest) a ui-tui-ban. Fontos tesztek: `slashParity`
  (Python regisztert tölt be — Windows-on `python` = Hermes Python, a `python3`
  a Microsoft Store ALIAS, ezért a teszt PYTHON env → python → python3
  sorrendben keres).
- Python: `scripts/run_tests.sh` a forrás gyökeréből (CI-paritás, ne direkt
  pytest).

## Frissítés után (hermes pip update) — ellenőrző lista

1. `hermes --version` — új verzió?
2. `model.favorites` RPC működik? (F2) — ha "unknown method", a server.py
   Model Favorites szekcióját újra át kell emelni (lásd 03_overlayek_rpc.md).
3. Computer use: `tools/computer_use` a site-packages-ben a fork verzió?
   (cua_backend auto-revive).
4. entry.js a tui_dist-ben a fork build?
5. `tui_dist\node_modules\ssh2` megvan? (frissítés törölheti → SFTP halál)
6. Config: `_config_version` — a hermes config show-val ellenőrizni, nem
   kell-e migráció.
7. Menük: File → Súgó megnyitja a sugo.md-t?
