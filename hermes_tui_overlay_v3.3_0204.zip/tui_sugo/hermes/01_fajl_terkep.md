# 01 — Fájltérkép (ui-tui/src + tui_gateway)

Minden fájl szerepkörrel. A sor-számok 2026-08-08 állapotot tükröznek
(frissítés: lásd 05_meretadatok.md).

## ui-tui/src — gyökér fájlok

| Fájl | Sor | Szerep |
|---|---|---|
| `entry.tsx` | 177 | Belépési pont. GatewayClient indítás, terminal módok, graceful exit, memória monitor |
| `app.tsx` | 25 | Legfelső komponens — vékony gyökér, az AppLayout-ot rendereli |
| `theme.ts` | 944 | Teljes téma/kinézet definíció (színek, keretek, DN stílus) |
| `gatewayClient.ts` | 794 | JSON-RPC kliens: spawn-olja a Python gateway-t, WS/sidecar, esemény dispatch |
| `gatewayTypes.ts` | 688 | Gateway esemény/üzenet típusok |
| `types.ts` | 229 | Közös TS típusok |
| `banner.ts` | 93 | Induló banner |

## ui-tui/src/components — a lényeg

| Fájl | Sor | Szerep |
|---|---|---|
| `appLayout.tsx` | 2274 | Fő elrendezés: menüsor, panelek, DN overlay, prompt sor, státusz. **A DN prompt/editor menü is itt van** |
| `menuBar.tsx` | 1061 | **A felső menüsor + MENUS tömb + F-gomb sor + F8/F9/F10 globális billentyűk. Ide kötődnek a menüpontok** |
| `dnPanelOverlay.tsx` | 756 | DN duál-panel fájlkezelő overlay (Tab váltás, ┌/┐ oszlopok, saját viewport, **kattintható fejléc — Sort by, Alt+←/→ — History**) |
| **`dnInternalEditor.tsx`** | **700** | **Belső néző/szerkesztő (DN Encoding, 2026-08-12)**: kék címsor + kék belső menüsor (File/Edit/Search/Paragraph/Block/Misc/Options), kódolásváltás F2-F7, hex F8, mentés az aktív kódolásban. A panelek felett renderelődik (F3 néző / F4 → Belső szerkesztő) |
| `dnFileOps.ts` | 631 | DN fájlműveletek: F5 másolás, F6 áthelyezés/átnevezés, F7 új mappa, F8 lomtár, F3 nézet, F4 editor menü + **sortEntries (Sort by) + pushHistory/stepHistory (History)** + **dnCreateFile() (Új fájl, 25. pont)** |
| `profileManagerOverlay.tsx` | 581 | Profilkezelő (session-picker stílus, ↑↓, d=törlés, Tab almenü) |
| `fpList.tsx` | 139 | FP (fájlgyűjtő) lista — tool.start eseményekből gyűjtött fájlok |
| `modelFavorites.tsx` | 263 | Kedvenc modellek (F2) — model.favorites RPC |
| `modelPicker.tsx` | 707 | Modell választó |
| `skillsHub.tsx` | 301 | Skill központ (keresés/telepítés/kezelés) |
| `skillCreatorOverlay.tsx` | 193 | Skill létrehozó |
| `skillInstallOverlay.tsx` | 96 | Skill telepítő |
| `skillDeleteOverlay.tsx` | 132 | Skill törlő |
| `pluginsHub.tsx` | 241 | Plugin központ |
| `subscriptionOverlay.tsx` | 1024 | Előfizetés/díjcsomag UI |
| `billingOverlay.tsx` | 950 | Számlázás |
| `agentsOverlay.tsx` | 976 | Ügynökök áttekintés |
| `activeSessionSwitcher.tsx` | 917 | Aktív session váltó |
| `appChrome.tsx` | 845 | Keret/ablak díszítés |
| `appOverlays.tsx` | 468 | Overlay-ek gyűjtő/regisztrációja |
| `overlay.tsx` / `overlayPrimitives.tsx` | 141/247 | Overlay alap építőkockák |
| `overlayScrollbar.tsx` / `overlayControls.tsx` | 84/50 | Overlay scrollbar + vezérlők |
| `infoMenuOverlay.tsx` | 44 | "Hermes & PC" info menü |
| `todoPanel.tsx` | 93 | Todo panel (jobb oldal) |
| `widgetGrid.tsx` | 267 | Ambient widget rács |
| `petPicker.tsx` / `petSprite.tsx` | 187/93 | Petdex kedvencek |
| `journey.tsx` | 595 | "Utazás" áttekintés |
| `helpHint.tsx` | 68 | Súgó tipp |
| `markdown.tsx` | 1165 | Markdown renderelő (belső megjelenítéshez) |
| `streamingMarkdown.tsx` | 166 | Streamelő markdown |
| `messageLine.tsx` | 276 | Üzenet sor |
| `streamingAssistant.tsx` | 118 | Streamelő asszisztens |
| `thinking.tsx` | 1246 | Gondolkodás/tool activity nézet |
| `textInput.tsx` | 1501 | Szövegbevitel (a legnagyobb komponens) |
| `prompts.tsx` | 312 | Prompt/approval UI |
| `maskedPrompt.tsx` | 41 | Rejtett (jelszó) prompt |
| `queuedMessages.tsx` | 64 | Sorban álló üzenetek |
| `loaders.tsx` | 172 | Betöltő animációk |
| `accordion.tsx` | 58 | Harmonika elem |
| `gridStreamsDemo.tsx` | 364 | Grid stream demo |
| `gridTestOverlay.tsx` | 318 | Grid teszt |
| `branding.tsx` | 562 | Márka/arculat |

## ui-tui/src — lib, hooks, store

- `lib/` — segédfüggvények: `terminalSetup.ts` (444), `externalLink.ts` (440),
  `platform.ts` (414), `mathUnicode.ts` (783), `widgetGrid.ts` (510),
  `clipboard.ts` (188), `terminalModes.ts` (103) — terminal mód reset,
  `openExternalUrl.ts` (158) — külső URL/alkalmazás nyitás.
- `lib/dnSftp.ts` (356) — **DN SFTP kapcsolatkezelő (ssh2): kapcsolat
  (sftpConnect, 15s timeout), lista cache (sftpListAsync/Sync), útvonal-segédek
  (sftpJoin/sftpDirname/sftpRoot), letöltés/feltöltés (sftpDownload/sftpUpload +
  Many változatok, fastGet/fastPut, "Már létezik a célban" védelem).**
- `lib/dnEncoding.ts` (81) — **a belső szerkesztő kódolási rétege (iconv-lite):
  CP437/850/852, ISO-8859-2, Windows 1250, UTF-8, hex — F2-F7 a belső
  néző/szerkesztőben.**
- `hooks/` — `useVirtualHistory.ts` (554), `useCompletion.ts` (134).
- `store/` — nanostore atomok (fpStore.ts a fájlgyűjtőhöz, overlay store stb.).
- `__tests__/` — vitest tesztek (pl. slashParity, fpStore).

## tui_gateway/ — Python backend

| Fájl | Sor | Szerep |
|---|---|---|
| `server.py` | 17238 | **A teljes RPC szerver. ~130+ metódus, `@method("név")` dekorátorral regisztrálva. Model Favorites szekció itt van (frissítés után újra kell emelni!)** |
| `entry.py` | 434 | Belépési pont (a TS `python -m tui_gateway.entry`-t futtat) |
| `compute_host.py` | 768 | Gép/session host infó |
| `project_tree.py` | 640 | Projekt fa |
| `host_supervisor.py` | 568 | Host felügyelet |
| `ws.py` | 476 | WebSocket |
| `slash_worker.py` | 179 | Slash parancs worker (subprocess) |
| `synthetic_turn.py` | 231 | Szintetikus turn |
| `transport.py` / `event_publisher.py` | 219/126 | JSON-RPC szállítás / esemény közzététel |
| `_stdin_recovery.py` | 151 | Stdin helyreállítás |

## Kritikus bekötési pontok

1. **Menüsor:** `ui-tui/src/components/menuBar.tsx` → `MENUS` tömb.
2. **Overlay-ek megnyitása:** `patchOverlayState({ <név>: true })` — a nevek a
   `appOverlays.tsx` overlay regisztrációjában és az overlay store-ban élnek.
3. **Slash parancs a kompozícióba:** `patchOverlayState({ fillInput: '/cmd ...' })`.
4. **RPC hívás:** a `useGateway()` hook `rpc` objektuma; a menuBar modul-szintű
   `_moduleRpc`-t tart (`_moduleRpc = rpc`), hogy a MENUS action-ök elérjék.
5. **Python oldali RPC:** `tui_gateway/server.py` `@method("...")` dekorátor.
6. **Globális F-billentyűk:** `menuBar.tsx` `useInput` blokk (F8 email, F9 AIMP,
   F10 exit) — `event.keypress.name` alapján.
