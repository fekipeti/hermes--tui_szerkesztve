# 09 — A DN fájlkezelő specifikációja (építési terv LLM-nek)

Ez a fájl a **DN fájlkezelő + belső néző/szerkesztő teljes építési
specifikációja**: mekkora ablak, milyen menük, és a 3 rétegű F1-F10 gombsor
pontos gombnevei és feladatai. Cél: ebből a leírásból egy LLM (vagy fejlesztő)
**újra fel tudja építeni** a fájlkezelőt, akkor is, ha a kód elveszne.
Minden adat a jelenlegi fork forrásából van mérve (2026-08-14).

Források a kódban: `ui-tui/src/components/dnPanelOverlay.tsx`,
`dnInternalEditor.tsx`, `appLayout.tsx`, `menuBar.tsx`.

---

## 1. A 3 réteg (melyik nézet melyik F-sort kapja)

| Réteg | Mikor aktív | F-gombsor | Mit csinál az F10 |
|---|---|---|---|
| **Hermes fő nézet** | alap (nincs overlay) | `KEY_HINT_ITEMS` | Kilépés a TUI-ból (az EGYETLEN kilépés) |
| **DN fájlkezelő** | `overlay.dnPanel` | `DN_KEY_HINT_ITEMS` | Vissza a Hermes-be (nem kilépés!) |
| **Belső néző/szerkesztő** | `overlay.dnInternal` | `INTERNAL_KEY_HINT_ITEMS` | Vissza a fájlkezelőbe |

A `FunctionKeyBar` (menuBar.tsx) az overlay-állapotból választ: `dnInternal` →
belső, `dnPanel` → DN, különben → Hermes. Az F5 felirata a DN rétegben
dinamikus (a `_dnFileActions.copyLabel` felülírja: "Letöltés a másik panelről"
/ "Feltöltés a másik panelre" / "Másolás a másik panelre").

---

## 2. A 3 réteg F1-F10 gombjai (pontos név + feladat)

### 2.1 Hermes fő nézet (`KEY_HINT_ITEMS`)

| Gomb | Felirat | Feladat |
|---|---|---|
| F1 | Súgó | a `help/sugo.md` megnyitása kedvenc MD-olvasóban (`cmd /c start`) |
| F2 | Model | Model Favorites / modellváltás |
| F3 | Cron | cron jobok |
| F4 | Memtest | memória & kontext ellenőrzés (fact_store round-trip, MEMORY.md/USER.md töltöttség, beszélgetés mentés; r = újrateszt) — a Skills központ a Hermes menü → /skills alatt maradt |
| F5 | Session | session picker |
| F6 | Plugins | plugin központ |
| F7 | Tools | tool lista |
| F8 | Email | Thunderbird workflow (fix script + MCP reload + "Mennyi email érkezett?") |
| F9 | AIMP | AIMP zenelejátszó indítása |
| F10 | Kilépés | teljes kilépés a TUI-ból (az egyetlen kilépő billentyű) |

### 2.2 DN fájlkezelő (`DN_KEY_HINT_ITEMS`)

| Gomb | Felirat | Feladat |
|---|---|---|
| F1 | Súgó | ugyanaz, mint a fő nézetben |
| F2 | Model | modellváltás (a fájlkezelőben is elérhető) |
| F3 | Nézet | **belső néző** megnyitása (kódolásváltóval; menüje: Belső néző / Notepad / VS Code / Megnyitás mással) |
| F4 | Szerkeszt | szerkesztő menü (Belső szerkesztő / Notepad / nano / gedit / mcedit / Notepad++ / VS Code) |
| F5 | Másolás | másolás a MÁSIK panelre (SFTP-vel: letöltés/feltöltés; a felirat dinamikus) |
| F6 | Áthelyez | áthelyezés a másik panelre (azonos könyvtárban: átnevezés) |
| F7 | Új mappa | új mappa létrehozása |
| F8 | Törlés | törlés a Lomtárba (NEM végleges — SendToRecycleBin) |
| F9 | AIMP | AIMP indítása (a DN rétegben is) |
| F10 | Hermes | vissza a Hermes fő nézetébe (a teljes kilépés CSAK onnan van) |

### 2.3 Belső néző/szerkesztő (`INTERNAL_KEY_HINT_ITEMS` — a harmadik réteg)

| Gomb | Felirat | Feladat |
|---|---|---|
| F1 | *(nincs — a sáv F2-től kezdődik)* | — |
| F2 | CP437 | kódolásváltás DOS (amerikai) |
| F3 | CP850 | kódolásváltás DOS (nyugat-európai) |
| F4 | CP852 | kódolásváltás **magyar DOS** |
| F5 | ISO-2 | kódolásváltás ISO 8859-2 |
| F6 | Win1250 | kódolásváltás Windows 1250 |
| F7 | UTF-8 | kódolásváltás UTF-8 |
| F8 | Hex | hex nézet ki/be (bináris dump) |
| F9 | Több | következő kódolás (CP 866, KOI8-R...) |
| F10 | Vissza | **vissza a fájlkezelőbe** (minden fókuszból, a kék menüből is; az Esc is előbb ide visz) |

> A belső rétegben a globális kezelésből CSAK a Ctrl+C interrupt marad — a
> F2/F3/F8/F9/F10 a szerkesztőé (nem a modell/AIMP/kilépés).

---

## 3. Ablakméretek és layout

### 3.1 DN fájlkezelő (duál panel)

- A **két panel együtt lefedi az ablak szélességét**, középen összeérve:
  - `cols = stdout.columns ?? 80`
  - `panelW = floor((cols - 1) / 2)` — mindkét panel ennyi, a jobb
    `marginLeft: 'auto'`-val a jobb szélre tolva
- **Magasság:** `rows = stdout.rows ?? 25`; a panelek látható sormagassága
  `visibleRows = max(4, rows - 11)` — a maradék 11 sor: 5 sor adat-widget +
  1 sor parancssor + 1 sor funkciógomb + 1 menüsor + keretek.
  A panel teljes magassága: `visibleRows + 3` (fejléc + lista + alsó keret).
- **Oszlopok:** `Name | Size | CDate | Desc`; `nameCol = max(10, panelW - 22)`,
  `cdateCol = 8`. A Name/Size/CDate **kattintható fejléc** — rendezés (új
  oszlop = növekvő, ugyanaz = irányváltás, ▼/▲ jelzés, aktív oszlop fehér).
  A könyvtárak MINDIG elöl, név szerint (DN hagyomány).
- **Panel felépítés** (fentről le): kék/aktív címsor (meghajtó + könyvtár) →
  oszlopfejléc → fájllista (viewport: a kijelölés mindig látható, középre
  igazítva) → az alsó keret. Megjelölt sorok sötét-sárga háttér (#4a4400),
  aktív sor fekete, aktív+jelölt = sárga betű.
- **A panelek ALATT** (külön sorok, nem a panel részei):
  1. **Adat-widgetek** (2 db, a panelekkel azonos szélesség): meghajtó,
     szabad hely (fs.statfs), könyvtár, kijelölt fájlok száma; a jobb oldaliban
     **[Hash] gomb** (SHA256 + vágólapra)
  2. **DN parancssor** (1 sor, #c0c0c0 háttér): drive bar (meghajtók
     kattinthatók; SFTP kapcsolat nélkül "SFTP...", kapcsolattal a cím) +
     szövegbevitel — Enter-re, ha létező könyvtár, az aktív panel oda lép
  3. **Funkciógomb-sor** (a 3 réteg szerint vált)
- **Interakciók:** Tab = panel váltás · Shift+↑/↓ = megjelölés + léptetés ·
  Ins = megjelölés · Ctrl+A = mindet · Esc = jelölés törlése (csak utána
  bezárás) · Alt+←/→ = könyvtár-előzmények · Backspace = szülő mappa ·
  Alt-C = Change drive (helyi lemezek + WSL + SFTP...) · **Alt-F7 = Keresés**
  (maszk dialógus → rekurzív találati lista → Enter = ugrás az aktív panelen;
  a Panel menüből a bal/jobb/mindkét panelre is — [L]/[J] jelzés) ·
  **Ctrl+D = Quick dirs** (kedvenc mappák, egy gombos ugrás; a lista a
  `dn_quickdirs.json`-ben perzisztens) · **Ctrl+F1/F2 = bal/jobb panel ki/be,**
  **Ctrl+P = inaktív panel ki/be** (a maradék panel teljes szélességben) ·
  **Ctrl+O = Compare** (a két mappa összevetése: [=] azonos, [≠] eltér,
  [<] csak balon, [>] csak jobbon; a csak-egyik-oldali + újabb fájlok
  MEGJELÖLŐDNEK, Tab/Shift+Tab = eltérés ugrás) · **Alt+D = Fájlok diff**
  (a két panel kurzorán lévő fájl tartalmának LCS-összevetése két hasábban;
  binárisnál HEX mód; SFTP-nél nincs) · **Alt+S = Mappaszinkron**
  (a Compare térképéből a csak-egyik-oldali + frissebb fájlok átmásolása
  a másik panelre; irányválasztó dialógus: Bal→Jobb / Jobb→Bal / Kétirányú;
  a diff-nél a frissebb FELÜLÍRJA a régebbit; NEM töröl; SFTP-nél nincs) ·
  jobb gomb = kontext menü

### 3.2 Belső néző/szerkesztő (dnInternalEditor)

- A **két panel FELETT teljes ablak** (a panelek helyett renderelődik),
  teljes szélesség; magasság: `bodyH = max(5, rows - 4)`.
- **Felépítés (fentről le):**
  1. **Kék címsor** (`titleH = 1`): `DN/2: Edit - <fájl út>` + óra (jobb szél)
  2. **Kék belső menüsor** (`menuH = 1`): `File · Edit · Search · Paragraph ·
     Block · Misc · Options` — Tab-bal léphetsz rá, ←/→ vált, Enter = almenü,
     Esc = vissza; egérrel is
  3. **Néző/szerkesztő test** (`bodyH`): a fájl tartalma; hex módban
     `dnHexDump()`; keresés (Ctrl+F) találati ugrás
  4. **Státuszsor** (`statusH = 1`): kódolás, sor:oszlop, módosítva jelzés
- **Szerkesztő:** kurzor + beszúrás + Backspace/Delete/Enter = új sor;
  Ctrl+S vagy File → Mentés az AKTÍV kódolásban (iconv-lite encode)
- **Keresés:** Ctrl+F vagy a kék menü Search → gépeld be, Enter = ugrás,
  Esc = kilép
- A **DN parancssor NINCS** a szerkesztő alatt (a TextInput nem lophatná a
  billentyűket); a funkciógomb-sor a szerkesztőé (2.3 réteg)
- A szerkesztőből visszatérve a kurzor **visszaugrik a szerkesztett fájlra**
  a fájlkezelőben

### 3.3 Kódolások (a belső néző/szerkesztő)

`lib/dnEncoding.ts` (iconv-lite): CP437, CP850, CP852, ISO-8859-2, Windows
1250, UTF-8 + hex dump. Az F9 "Több" a CP 866, KOI8-R stb. között lépked.

---

## 4. Menük a DN fájlkezelőben (a felső menüsor)

A felső menüsor a DN módban is ugyanaz (File / Hermes / Manager / Utilities /
Panel / Options / Window), de a **Manager** menü DN-pontjai csak DN módban
aktívak (Hermes módban szürkék — `dnDisabled`):

- **File:** New session, New tab, TUI frissítés, Köszönet az alkotóknak,
  Súgó (F1), Parancsok, **Új fájl ▸** (txt/md/lnk/üres — csak DN módban,
  `dnOnly`), Exit
- **Hermes:** /skills, /model, /sidepanel, /ticker, /weather, aktív widgetek
- **Manager:** FP — Fájlkezelő (a DN belépő), FP — feladat szerkesztett
  fájljai, Change drive (Alt-C), **Quick dirs (Ctrl+D)** — kedvenc mappák
  egy gombos ugrás, **Keresés... (Alt-F7)** — rekurzív maszkos keresés,
  **Összehasonlítás (Compare, Ctrl+O)** — a két panel összevetése,
  **Fájlok diff (Alt+D)** — a két kurzorfájl tartalmának összevetése,
  **Mappaszinkron... (Alt+S)** — az eltérések átmásolása a másik panelre
  (a fájlműveletek a **Panel → Fájlműveletek ▸** alatt vannak:
  Kijelölés, Vágólapra, F5-F8, Nézet/Szerkesztés/Frissítés),
  Profilkezelő, Hermes & PC eszközök
- **Utilities:** Thunderbird (F8), AIMP (F9), tldraw offline, ComfyUI,
  Hermes & PC (cua-driver), Ambient Widget rendszer
- **Panel:** **Panel nézet ▸** (Normál nézet / **Flat nézet** — az összes
  almappa fájlja egy listában, Ctrl+B is), **Keresés ▸** (a bal panelen / a
  jobb panelen / **mindkét panelen** — a találati listában [L]/[J] jelzi a
  találat oldalát, Enter = ugrás arra a panelre), **Rendezés ▸** (név/méret/
  dátum az aktív panelen), **Panel elrejtés ▸** (bal Ctrl+F1 / jobb Ctrl+F2 /
  inaktív Ctrl+P — a maradék panel teljes szélességben), Panel beállítások
  (bal/jobb, terv), Panel csere (swap, tervezett), Minden ablak bezárása (Esc)
- **Options:** Hermes beállítások, Megjelenés (skin)
- **Window:** Teljes képernyő (Alt+Enter), Normál nézet, Maximalizálás
  (Win+↑), Visszaállítás (Win+↓)

---

## 5. Hivatkozások a kódban

| Mit | Hol |
|---|---|
| F-gomb sorok (3 réteg) | `menuBar.tsx` ~1035-1090 (`KEY_HINT_ITEMS`, `DN_KEY_HINT_ITEMS`, `INTERNAL_KEY_HINT_ITEMS`, `FunctionKeyBar`) |
| Duál panel méretezés | `dnPanelOverlay.tsx` ~621-660 |
| Kattintható fejléc + rendezés | `dnPanelOverlay.tsx` + `dnFileOps.ts` (`sortEntries`, `SortSpec`) |
| Könyvtár-előzmények | `dnFileOps.ts` (`DirHistory`, `pushHistory`, `stepHistory`) |
| Belső néző/szerkesztő | `dnInternalEditor.tsx` (700 sor) + `lib/dnEncoding.ts` (81 sor) |
| DN widgetek + parancssor | `appLayout.tsx` ~1615-1660 |
| A menüsor bekötése | `menuBar.tsx` `MENUS` tömb (lásd 02_menu_bekotes.md) |
| A hátralévő fejlesztés | 08_hatralevo_terv.md (a 24 pont + kisablakos chat) |

*Frissítve: 2026-08-24 (Compare/diff/Mappaszinkron + a menü-átrendezés a specben).*
