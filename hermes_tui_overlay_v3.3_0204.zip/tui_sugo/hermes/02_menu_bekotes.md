# 02 — Menü bekötés receptje

Hogyan néz ki a menüsor, és hogyan adható hozzá új menüpont / overlay /
F-billentyű. Minden minta a jelenlegi `menuBar.tsx`-ből való.

## A MENUS tömb szerkezete

```ts
const MENUS: MenuDef[] = [
  {
    label: 'File',
    items: [
      { label: 'New session', shortcut: '/new', action: () => patchOverlayState({ fillInput: '/new ' }) },
      { label: '────────────────────────────────────', action: undefined },  // elválasztó
      { label: 'Köszönet az alkotóknak', action: () => patchOverlayState({ menuInfo: { title: '...', detail: '...' } }) },
      { label: 'Exit', shortcut: 'Kilépés + takarítás', action: exitHermesTui },
    ]
  },
  { label: 'Hermes', items: [ ... ] },
  { label: 'Manager', items: [ ... ] },
  // ... további menük
]
```

Egy `MenuItem` mezői:
- `label` — megjelenő szöveg (kötelező)
- `shortcut` — jobb oldali kis felirat (opcionális)
- `action` — kattintáskor futó függvény (opcionális; `undefined` = elválasztó
  vagy inaktív)
- `subItems` — almenü (pl. `SKILLS_SUBMENU`)
- `dnOnly` — a pont CSAK a DN fájlkezelőben (overlay.dnPanel) látható
- `dnDisabled` — a pont csak a DN fájlkezelőben AKTÍV; Hermes módban szürke,
  nem kattintható (7. kör: a DN-specifikus menük így szürkülnek, a FP-belépő
  aktív marad)

## DN menük szürkítése (dnDisabled — 7. kör)

A Manager menü DN-pontjai (F5 másolás, F6 áthelyezés, F7 új mappa, F8 törlés,
F3 nézet, F4 szerkesztés, Change drive, Kijelölés, Vágólapra...) `dnDisabled:
true` flaggel élnek: Hermes módban szürkék és kattintásra nem reagálnak, a DN
fájlkezelő megnyitásakor (FP — Fájlkezelő pont) válnak aktívvá. A szürkítés a
menuBar.tsx `MENUS` feldolgozásában történik (`overlay.dnPanel` alapján).

## Dinamikus menücímkék (copyLabel — 8. kör)

A File/Manager menü "Másolás a másik panelre" pontjának CÍMKÉJE a két DN-panel
módjától függően változik — az appLayout a `setDnFileActions`-ban adja át
(`DnFileActions.copyLabel`), a menuBar a `dnCopyLabelText()` helperrel olvassa:
- SFTP panel → helyi másik panel: **"Letöltés a másik panelről"**
- helyi panel → SFTP másik panel: **"Feltöltés a másik panelre"**
- különben: "Másolás a másik panelre"

Ugyanez a logika adja az alsó F5 funkciógomb feliratát is (a FunctionKeyBar a
`DN_KEY_HINT_ITEMS` F5 elemét felülírja a copyLabel-lel).

## Rendezés almenü (Sort by — 9. kör, 2026-08-11)

A Manager menü **Rendezés** almenüje (Kijelölés és Vágólapra almenük mellett):
Név szerint / Méret szerint / Dátum szerint — az AKTÍV panelen vált módot
(az irány marad). Emellett **a panel fejlécére kattintva** is rendezhető:
Name/Size/CDate — új oszlop = növekvő, ugyanaz = irányváltás (▼/▲ jelzés,
az aktív oszlop fehér). A könyvtárak a DN hagyomány szerint MINDIG elöl és
név szerint rendezettek, csak a fájlok követik a módot+irányt.

Fájlok:
- `dnFileOps.ts`: `SortMode`/`SortSpec` típusok + `sortEntries()` (tiszta,
  tesztelhető — `src/__tests__/sortEntries.test.ts`, 6 teszt) + `sortHeaderLabel()`
- `appLayout.tsx`: `dnSort` state (panelonként), `setDnFileActions.sortBy(mode)`,
  a két panel `sortSpec`/`onSortChange` propjai
- `dnPanelOverlay.tsx`: kattintható fejléc (3 szegmens), a readDir/SFTP-lista
  a `sortEntries`-en megy át
- `menuBar.tsx`: `DnFileActions.sortBy` + `RENDEZES_SUBMENU`

## Könyvtár-előzmények (History — 9. kör, 2026-08-11)

Alt+← = vissza, Alt+→ = előre a látogatott mappák közt (böngésző-modell:
belépéskor push, visszalépés után új belépésnél a forward törlődik; max 50
elem). A státusz sorba írja: "Előzmény: 3/7". A Backspace változatlanul a
SZÜLŐ mappába lép (DN szokás) — az Alt+← a történetben lép.

Megvalósítás:
- `dnFileOps.ts`: `DirHistory` típus + `pushHistory()` + `stepHistory()`
  (tiszta függvények — `src/__tests__/dnHistory.test.ts`, 8 teszt)
- `appLayout.tsx`: `dnHist` state (panelonként), a `dir` változást figyelő
  useEffect push-ol, `dnGoHist()` az Alt+←/→; egy `dnHistNav` ref jelzi a
  navigációt, hogy az NE push-oljon
- `dnPanelOverlay.tsx`: `onHistory(delta)` prop + Alt+←/→ a useInput-ban

## Menüpont akció-típusok (a leggyakoribbak)

| Cél | Minta |
|---|---|
| Overlay megnyitása | `action: () => patchOverlayState({ dnPanel: true })` |
| Slash parancs beírása | `action: () => patchOverlayState({ fillInput: '/new ' })` |
| Infó ablak (title+detail) | `action: () => patchOverlayState({ menuInfo: { title: 'T', detail: 'D' } })` |
| Kilépés | `action: exitHermesTui` |
| Külső program/fájl nyitása | `action: () => spawn('cmd', ['/c', 'start', '', 'C:\\path\\file.md'], { detached: true, stdio: 'ignore', windowsHide: true })` |
| RPC hívás | `action: () => { void _moduleRpc?.call('method.name', {...}) }` |

## Új overlay bekötése (teljes út)

1. Készítsd el a komponenst: `components/<Név>Overlay.tsx` — a meglévő
   overlay-ek mintájára (overlay.tsx primitívek).
2. Regisztráld az `appOverlays.tsx` overlay-gyűjtőben (a state név kulcs).
3. Az overlay store-ban (store/) add hozzá a state kulcsot (`dnPanel: boolean`
   stb. mintájára).
4. Menüpont: `menuBar.tsx` MENUS tömb → `{ label: '...', action: () => patchOverlayState({ <név>: true }) }`.
5. Típuscheck: `npm run typecheck`. Build: `npm run build`.

## F-billentyű bekötése (globális)

A `MenuBar` komponens `useInput` blokkjában (menuBar.tsx ~609. sor):

```ts
useInput((ch, key, event) => {
  if ((event as any)?.keypress?.name === 'f10') { exitHermesTui(); return }
  if ((event as any)?.keypress?.name === 'f9') { spawn('C:\\Program Files (x86)\\AIMP\\AIMP.exe', [], { detached: true, stdio: 'ignore', windowsHide: true }); return }
  if ((event as any)?.keypress?.name === 'f8' && !overlay.dnPanel) { void launchThunderbird(rpc); patchOverlayState({ fillInput: 'Mennyi email érkezett?' }); return }
})
```

Fontos:
- `key.fn` BUGOS — mindig `event.keypress.name`-et használj.
- Ha DN overlay aktív, az F8-at a fájlkezelő kezeli (törlés) — ezért a
  `!overlay.dnPanel` guard.
- Az alsó funkciógomb feliratokat a `KEY_HINT_ITEMS` / `DN_KEY_HINT_ITEMS`
  tömbök tartalmazzák — a felirat és a tényleges akció külön él.

## Belső szerkesztő F-gomb bekötése (3. réteg — 2026-08-12)

A belső néző/szerkesztő (`dnInternalEditor.tsx`) a KÉT PANEL FELETT teljes ablak,
saját F-gomb-réteggel (kódolásváltók), ami a globális F-kezelésből ki van zárva:

- **F2-F7 = kódolásváltók** (CP437/CP850/CP852/ISO-8859-2/Win1250/UTF-8) +
  **F8 = Hex** + **F9 = következő kódolás** + **F10 = vissza a fájlkezelőbe**
- A belső szerkesztőben a globális kezelésből CSAK a Ctrl+C interrupt marad
  (a F2/F3/F8/F9/F10 ütközés-mentesítve a fő nézet DN- és modell-gombjaival)
- A kék belső menüsor (File/Edit/Search/Paragraph/Block/Misc/Options) Tab-bal
  navigálható — a menüből is működnek a kódolásváltók (a 2c56901f commit javítása)
- **Bekötés:** `menuBar.tsx` F-gomb sor + `useInputHandlers.ts`
  (dnPanel/dnInternal kizárással) + a `dnInternalEditor.tsx` saját useInput-ja;
  a `dnInternal` state az overlayStore-ban él
- **A DN parancssor elrejtve a szerkesztő alatt**; a belső szerkesztőből
  visszatérve a kurzor visszaugrik a szerkesztett fájlra (e51fb072)

## A Súgó menüpont (a jelenlegi minta)

A File menüben, a "Köszönet az alkotóknak" UTÁN:

```ts
{ label: 'Súgó', action: () => {
  spawn('cmd', ['/c', 'start', '', 'C:\\Users\\fekec\\AppData\\Local\\hermes\\help\\sugo.md'],
    { detached: true, stdio: 'ignore', windowsHide: true })
} },
```

Ezt nyitja a kedvenc MD olvasóban (a .md asszociáció alapján). Windows
speciális: `cmd /c start` kell, mert a direkt `execFile`/`spawn` a Store-os
stubokat eldobja (Notepad-tanulság).

## Window menü (ablak állapot — 2026-08-06)

A Window menü három valódi akciót köt be, a `window-state.ps1` scripten át
(`C:\Users\fekec\AppData\Local\hermes\scripts\window-state.ps1`):

| Menüpont | Shortcut | Mit csinál |
|---|---|---|
| Teljes képernyő | Alt+Enter | Windows Terminal `toggleFullscreen` (default binding, MS docs) — SendKeys `%{ENTER}` a fókuszált terminálnak |
| Normál nézet (ablakméret) | Alt+Enter | Ugyanaz a toggle visszafelé — fullscreenből visszahozza az ablakot (a SendKeys toggle mindkét irányba működik) |
| Maximalizálás (tálca látszik) | Win+↑ | `ShowWindow(GetConsoleWindow(), SW_MAXIMIZE=3)` |
| Visszaállítás (ablakméret) | Win+↓ | `ShowWindow(GetConsoleWindow(), SW_RESTORE=9)` |

```ts
const runWindowAction = (action: 'fullscreen' | 'maximize' | 'restore') => {
  spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', WINDOW_STATE_SCRIPT, '-Action', action], {
    windowsHide: true, stdio: 'ignore'
  })
}
```

Tanulságok:
- A `GetConsoleWindow()` a TUI konzolablakát adja, mert a spawn-olt PowerShell
  örökli a TUI konzolját. Fejlesztői shellből tesztelve `NO CONSOLE WINDOW` —
  a headless shellnek nincs ablaka, ezért NEM lehet onnan biztonságosan
  tesztelni a maximálzást (nem ugrál a TUI ablaka).
- A Windows Terminalnak NINCS külön maximize action-je — az ablak-szintű
  Win+↑/Win+↓ a Windowsé, API-ból `ShowWindow`.
- F11 is toggleFullscreen a Windows Terminalban (default binding), de az
  Alt+Enter a közismert — a menüben az Alt+Enter szerepel.

## Spawn használata Windows-on (tanulságok)

- Külső program: `spawn('cmd', ['/c', 'start', '', 'path'], { detached: true, stdio: 'ignore', windowsHide: true })`
- `windowsHide: true` — ne villanjon fel ablak.
- A TUI-editerek (nano, gedit, mcedit WSL-ben): `wt.exe` külön ablakban,
  fallback `cmd start`.
- Notepad: `cmd /c start` KELL (Win11 Store-os stub a direkt execFile-t eldobja).
