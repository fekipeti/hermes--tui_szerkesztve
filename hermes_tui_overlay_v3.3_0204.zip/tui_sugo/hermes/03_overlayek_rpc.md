# 03 — Overlay-ek és RPC metódusok

## Overlay-ek (patchOverlayState kulcsok)

A `patchOverlayState({ <név>: true })` hívással nyitható overlay-ek. A nevek
az overlay store-ban és az `appOverlays.tsx` regisztrációban élnek.

| Overlay | Mit csinál |
|---|---|
| `dnPanel` | DN duál-panel fájlkezelő |
| `dnChangeDrive` | DN Change drive... (Alt-C) — meghajtó-váltó: helyi betűk, WSL disztribúciók, SFTP kapcsolat |
| `dnInternal` | **Belső néző/szerkesztő (2026-08-12)** — a két panel FELETT teljes ablak, kódolásváltó F-gombsorral (a dnInternalEditor.tsx); az overlayStore-ban él, a DN fájlkezelőből nyílik (F3 néző / F4 → Belső szerkesztő), F10 = vissza a fájlkezelőbe |
| `profileManager` | Profilkezelő |
| `modelFavorites` | Kedvenc modellek (F2) |
| `skillsHub` | Skill központ |
| `skillCreator` / `skillInstall` / `skillDelete` | Skill CRUD |
| `pluginsHub` | Plugin központ |
| `sessions` | Session picker |
| `menuInfo` | Infó ablak (`{title, detail}`) |
| `fillInput` | Nem overlay: szöveget ír a kompozícióba (slash parancsokhoz) |

## RPC metódus katalógus (tui_gateway/server.py)

Teljes lista 2026-08-06 állapot szerint (`grep '@method("' server.py`).
A `@method("...")` dekorátor regisztrálja; a TS oldal `rpc.call('név', params)`.

**Session:** `session.activate`, `session.active_list`, `session.branch`,
`session.close`, `session.compress`, `session.context_breakdown`,
`session.create`, `session.cwd.set`, `session.delete`, `session.history`,
`session.interrupt`, `session.list`, `session.most_recent`,
`session.redirect`, `session.resume`, `session.save`, `session.status`,
`session.steer`, `session.title`, `session.undo`, `session.usage`

**Modell:** `model.disconnect`, `model.favorites`, `model.favorites.set`,
`model.options`, `model.save_key`

**Prompt/chat:** `prompt.background`, `prompt.submit`

**Slash/parancsok:** `slash.exec`, `command.dispatch`, `command.resolve`,
`commands.catalog`, `complete.path`, `complete.slash`

**Config:** `config.get`, `config.set`, `config.show`

**Skills/plugins/tools:** `skills.manage`, `skills.reload`,
`plugins.list`, `plugins.manage`, `tools.configure`, `tools.list`,
`tools.show`, `toolsets.list`, `tool.configure`

**Cron:** `cron.manage`

**Delegáció:** `delegation.pause`, `delegation.status`, `subagent.interrupt`

**Fájlok:** `file.attach`, `image.attach`, `image.attach_bytes`,
`image.detach`, `pdf.attach`

**Clipboard:** `clipboard.paste`, `paste.collapse`

**Pet (petdex):** `pet.cancel`, `pet.cells`, `pet.disable`, `pet.export`,
`pet.gallery`, `pet.generate`, `pet.generate.status`, `pet.hatch`,
`pet.info`, `pet.info.meta`, `pet.remove`, `pet.rename`, `pet.scale`,
`pet.select`, `pet.thumb`

**Billing/subscription:** `billing.auto_reload`, `billing.charge`,
`billing.charge_status`, `billing.state`, `billing.step_up`,
`subscription.change`, `subscription.preview`, `subscription.resume`,
`subscription.state`, `subscription.upgrade`

**Agents:** `agents.list`

**Projects:** `projects.discover_repos`, `projects.project_sessions`,
`projects.record_repos`, `projects.tree`, `project.facts`

**Insights/learning:** `insights.get`, `learning.delete`, `learning.detail`,
`learning.edit`, `learning.frames`

**System:** `system.battery`, `setup.runtime_check`, `setup.status`,
`verification.status`, `usage.bars`, `voice.record`, `voice.toggle`,
`voice.tts`, `terminal.resize`, `terminal.read.respond`, `input.detect_drop`

**Process:** `process.kill`, `process.list`, `process.stop`

**Shell:** `shell.exec`

**Spawn tree:** `spawn_tree.list`, `spawn_tree.load`, `spawn_tree.save`

**Egyéb:** `approval.respond`, `clarify.respond`, `sudo.respond`,
`secret.respond`, `handoff.fail`, `handoff.request`, `handoff.state`,
`llm.oneshot`, `reload.env`, `reload.mcp`, `rollback.diff`,
`rollback.list`, `rollback.restore`, `browser.manage`, `preview.restart`

## FIGYELEM: frissítés utáni újraemelés

A `hermes` frissítés FELÜLÍRJA a site-packages `tui_gateway/server.py`-t.
A fork-specifikus szekciók (pl. **Model Favorites**: `model.favorites` +
`model.favorites.set`) elvesznek → "unknown method: model.favorites" hiba.
Fix: a `C:\tmp\herm_tui\forras\tui_gateway\server.py` megfelelő szekcióját át
kell emelni a site-packages verzióba. Ugyanez igaz a `tools/computer_use`
mappára (cua_backend auto-revive) és a `hermes_cli/tui_dist/entry.js`-re.
