# Hermes TUI — Súgó (Péter fork)

Ez a Hermes terminál felület (TUI) személyre szabott változata. Az alábbiakban
mindent megtalálsz, ami a napi használathoz kell. A műszaki részletek
(Hermesnek szóló térkép) a `hermes/` mappában vannak.

---

## Billentyűparancsok

| Billentyű | Mit csinál |
|---|---|
| **F1** | Súgó (ez a fájl) |
| **F2** | Modell váltás (Kedvencek) |
| **F3** | Cron jobok |
| **F4** | Skills |
| **F5** | Session picker |
| **F6** | Plugins |
| **F7** | Tools |
| **F8** | Email (Thunderbird + MCP, automatikus) |
| **F9** | AIMP indítása |
| **F10** | Kontextusfüggő: fő nézetben kilépés, fájlkezelőben vissza a Hermes-be, belső szerkesztőben vissza a fájlkezelőbe |
| **Tab** | DN overlay: panel váltás |
| **Ctrl+X** | Session picker |
| **Ctrl+C** | Másolás (ha van kijelölés) / interrupt (ha AI válaszol) — NEM lép ki |
| **Egér** | Menük, kattintás, görgetés támogatott |

> Megjegyzés: Ctrl+C sosem törli a beviteli mezőt és nem lép ki — arra F10 van.

---

## Felső menüsor

**File**
- New session — új beszélgetés
- New tab — (tájékoztatás: a TUI nem támogat tab-ot, a dashboard igen)
- TUI frissítés / config update / pip update — frissítési infók
- **Köszönet az alkotóknak** — a Nous Research csapat névsora
- **Súgó** — ez a fájl (kedvenc MD olvasóban nyílik)
- Parancsok — gyors parancs lista
- Exit — kilépés

**Hermes**
- /skills — skill kezelés (keresés, telepítés, törlés)
- /model — modell váltás
- /sidepanel, /ticker, /weather — widgetek indítása
- Aktív widgetek listája

**Manager**
- FP — Fájlkezelő (DOS Navigator stílusú duál panel)
- FP — feladat szerkesztett fájljai ([FP] jelzés a menüsorban)
- Change drive (Alt-C) — lemezek + WSL + SFTP
- **Kijelölés ▸** — Select group (maszk, pl. *.txt), Mindent kijelöl (Ctrl+A), Kijelölés törlése (Esc)
- **Vágólapra ▸** — nevek / teljes útvonal / aktuális fájl a Windows vágólapra
- **Rendezés ▸** — Név / Méret / Dátum szerint (a panel fejlécére kattintva irány is váltható)
- DN fájlműveletek (F5 másolás, F6 áthelyezés, F7 új mappa, F8 törlés, F3 nézet, F4 szerkesztés, Csoportos átnevezés Ctrl+M, Frissítés)
- Profilkezelő
- Hermes & PC eszközök

> A Kijelölés / Vágólapra / Rendezés / DN-műveletek csak a DN fájlkezelőben
> (FP) aktívak — Hermes módban szürkén látszanak, de nem kattinthatók.

**Utilities (Eszközök)**
- **Thunderbird** (F8) — email workflow (fix script + MCP reload + kérdés)
- **AIMP** (F9) — zenelejátszó indítás
- **tldraw offline** — rajzolás (a tldraw offline API-jával)
- **ComfyUI (AI képgenerálás)** — képgenerátor indítás
- **Hermes & PC** — cua-driver indítás / állapot (computer use)
- **Ambient Widget rendszer** — widgetek indítása, listázása

**Panel**
- Panel beállítások (bal/jobb) — fejlesztés alatt
- Panel csere (swap) — fejlesztés alatt
- Minden ablak bezárása (Esc)

**Options**
- Hermes beállítások — a config.yaml útvonala, `hermes config set`
- Megjelenés (skin) — téma váltás

**Window**
- Teljes képernyő (Alt+Enter) / Normál nézet / Maximalizálás (Win+↑) / Visszaállítás (Win+↓)

---

## DN fájlkezelő (DOS Navigator stílus)

A **Manager → FP** menüvel (vagy F4-gyel a fájlok közt) nyitható duál panel
fájlkezelő.

| Billentyű | Művelet |
|---|---|
| **Tab** | Panel váltás (bal/jobb) |
| **Shift+↑/↓** | Többes kijelölés (megjelölés + léptetés; Ins is működik) |
| **Ctrl+A** | Mindent kijelöl |
| **Esc** | Kijelölés törlése (csak utána zárja be a panelt) |
| **Alt+← / Alt+→** | Könyvtár-előzmények: vissza / előre (a látogatott mappák közt) |
| **F3** | Nézet — **belső néző** (kódolásváltással, hex nézettel) |
| **F4** | Szerkesztő menü (Belső szerkesztő, Notepad, nano, gedit, mcedit, Notepad++, VS Code...) |
| **F5** | Másolás a másik panelre |
| **F6** | Áthelyezés (azonos könyvtárban: átnevezés) |
| **F7** | Új mappa |
| **F8** | Törlés a Lomtárba (nem végleges!) |
| **F10** | Vissza a Hermes fő nézetébe (a teljes kilépés csak onnan van) |
| **Jobb gomb** | Kontext menü |
| **┌ / ┐** | Oszlopok: Név, Méret, Dátum, Leírás |

**Menüből (Manager):** Kijelölés ▸ (Select group maszk, mindent, törlés),
Vágólapra ▸ (nevek / útvonallal / aktuális fájl), Rendezés ▸ (név/méret/dátum).

## Belső néző / szerkesztő (kódolásváltás)

Az **F3** mostantól a belső nézőt nyitja (a külső programok az F4 menüből
érhetők el: „Belső szerkesztő" + Notepad, nano, VS Code...). A belső ablak a
két panel felett, DN stílusban:

- **Kék címsor**: `DN/2: Edit - C:\tmp\fájl` + óra
- **Kék menüsor**: File · Edit · Search · Paragraph · Block · Misc · Options
  (Tab-bal lépsz rá, ←/→ vált, Enter = almenü, Esc = vissza; egérrel is)
- **Kódolásváltás az F-sorral** (az alsó gombsor ilyenkor a szerkesztőét
  mutatja — 3 rétegű: Hermes fő nézet / DN fájlkezelő / belső szerkesztő):
  F2 = CP 437 · F3 = CP 850 · F4 = CP 852 (magyar DOS) · F5 = ISO 8859-2 ·
  F6 = Windows 1250 · F7 = UTF-8 · F8 = Hex nézet · F9 = következő (CP 866,
  KOI8-R) · **F10 = Vissza a fájlkezelőbe** (minden fókuszból — a kék
  menüből is; az Esc is előbb ide visz)
- **Szerkesztő (F4 → Belső szerkesztő)**: a kurzorral írsz (↑↓←→, Backspace,
  Enter = új sor), **Ctrl+S vagy File → Mentés** ment az aktív kódolásban
- **Keresés**: **Ctrl+F** vagy a kék menü Search → gépeld be, Enter = ugrás,
  Esc = kilép
- A státuszsor mutatja: kódolás, sor:oszlop, módosítva jelzés

WSL útvonalak: `/mnt/c/...` — figyelj a perjelre a drive betű után!

---

## SFTP — kapcsolódás távoli szerverhez

A fájlkezelő a **Change drive**-ból (Alt-C) SFTP-n keresztül eléri a távoli
Linux szervereket (Ubuntu openssh-server — a leggyakoribb SSH-szerver, az
SFTP benne van).

**Kapcsolódás:**
1. **Alt-C** (Change drive) → a lista végén: **SFTP...**
2. **Enter** → beírod: `felhasználó@cím` (pl. `user@192.168.1.50`)
   - Ha más port kell: `felhasználó@cím:2222` (alap: 22)
3. **Jelszó** → Enter → a panel a szerver fájljait mutatja
   - Enter = mappába lépés, Backspace = feljebb (a gyökérnél megáll)

**WSL-teszt (helyi próba):** a WSL Ubuntu-ba `user@<IP>`-vel lépsz be,
ahol az IP-t a `wsl hostname -I` parancs írja ki (a WSL újraindulásakor
**változhat**). A `localhost` jelenleg nem megy (Windows forwarding hiba).

**Tudni érdemes:**
- A jelszó **nem marad meg** — minden kapcsolódásnál újra bekéri (biztonságos)
- Hibaüzenetek: „kapcsolat elutasítva" (nincs SSH a címen), „időtúllépés —
  tűzfal blokkolja?" (a tűzfalban engedélyezni kell a kimenő SSH-t),
  „ismeretlen cím" (elgépelted)
- A kapcsolat után a drive bar-ban **SFTP felhasználó@cím** jelenik meg —
  arra kattintva visszalépsz a szerver gyökerére

**Letöltés / feltöltés (F5):** ha az egyik panel SFTP-n van, a másik helyi:
- **F5** a szerver oldalán → **letöltés** (a szerver fájlja a helyi panelre)
- **F5** a helyi oldalon → **feltöltés** (a helyi fájl a szerverre)
- Ha a célban már van ilyen nevű fájl, **nem írja felül** — hibaüzenetet ad
- Megjelöléssel (Ins) egyszerre több fájl is megy
- Az F5 gomb felirata mutatja, mit csinál: Letöltés / Feltöltés / Másolás

---

## Widgetek (jobb oldali panel)

- **/sidepanel** — óra + todo + Hermes info
- **/ticker** — tőzsde sparkline
- **/weather** — időjárás
- Aktív widgetek: Eszközök menüből listázhatók, kapcsolhatók

---

## Profilok

A **Manager → Profilkezelő** menüben:
- ↑↓ navigáció, Enter = váltás, `d` = törlés (2× megerősítés)
- Tab = almenü (modell, munkakönyvtár)
- A váltás a TUI újraindítása után lép életbe
- A `default` profil nem törölhető

Profilok: `default`, `tui`, `hazi-feladat`, `qwenticoo`.

---

## Gyakori parancsok

```
/model        - Modell váltás
/model-fav    - Kedvenc modellek (F2)
/skills       - Skill kezelés
/cron         - Cron jobok
/sessions     - Session picker
/new          - Új session
/resume last  - Legutóbbi session folytatása
/tools        - Tool lista
/plugins      - Plugin kezelés
/sidepanel    - Jobb oldali panel
/help         - Súgó
```

---

## Tippek

- **F8 email**: automatikusan elindítja a Thunderbird MCP-t, megjavítja a
  permission mappát, és beírja a "Mennyi email érkezett?" kérdést.
- **F9 AIMP**: zenelejátszó indítás egy gombbal.
- **F10**: a teljes kilépés CSAK a Hermes fő nézetéből van — a fájlkezelőben visszalép a Hermes-be, a belső szerkesztőben a fájlkezelőbe. Ctrl+C, Ctrl+D nem lép ki.
- A TUI a forrásból indul (`npm start`), így minden módosítás azonnal él.
- A menük útvonalai a felhasználónevet futásidőben kérik le — a TUI másik
  gépen is működik (a programoknak a szokásos helyen kell lenniük).
- Lassú válasz? F2-vel válts gyorsabb cloud modellre (gpt-oss:20b:cloud).

---

## Telepítés másik gépre (pendrive)

A `C:\tmp\pendrive2` csomag (2.0, 2026-08-14 — entry.js + ssh2 node_modules +
server.py + cua_backend.py + telepites.bat + OLVASD_EL.txt) a tiszta hermes
0.19.0 fölé telepíthető:
1. Python 3.13 + Node 20+ + `pip install hermes-agent==0.19.0`
2. `telepites.bat` futtatása (backup-pal felülírja a TUI fájljait: entry.js,
   node_modules/ssh2, server.py, cua_backend.py)
3. `hermes --tui` — az ssh2 a csomagban lévő node_modules-ből töltődik

A csomag leírásai a pendrive2 mappában: `OLVASD_EL.txt` (telepítési útmutató),
`hermes_modositasok_es_programok.md` (a fork változásai + programlista),
`f8_f9_workflow.md` (Thunderbird/AIMP), és a `tui_sugo/` (ez a Súgó).

> **Megjegyzés a verzióról:** a naprakész gép (fekec) már hermes **0.20.1**-t
> futtat (2026-08-13), de a pendrive-csomag a 0.19.0-hoz készült — a célgépen
> a telepítő a 0.19.0-t várja. Mindkét verzióra igaz, hogy a fork aktív.

---

*Utolsó frissítés: 2026-08-14*

> **Tervezett (még nincs benne a TUI-ban):** a DN-fájlkezelő 24 pontos bővítési
> listájából a **Flat nézet** (Ctrl+B, az összes almappa fájlai egy listában)
> van hátra a "6 kedvenc" közül; az egyéb tervezett pontok (gyors könyvtárak,
> keresés, mappa-összehasonlítás, fájlszűrő, panel-elrejtés, VFS-archívum stb.)
> és a **kisablakos chat** ötlete a műszaki térképben: `hermes/08_hatralevo_terv.md`.

---

*FP lista teszt — 2026-08-06: ezt a sort a Hermes írta, hogy az FP gyűjtőt élőben teszteljük.*
