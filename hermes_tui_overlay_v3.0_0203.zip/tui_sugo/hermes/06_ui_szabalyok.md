# 06 — UI szabályok (Péter preferenciái)

Ezeket a szabályokat MINDIG be kell tartani a TUI módosításakor. Péter
többször kijavított ezekre — megszegésük frusztrációhoz vezet.

## Kinézet

1. **Nagy kontraszt, fehér betűk.** Péter idősödő, gyengébb szemű — a
   fájlkezelőben és a panelekben kifejezetten **fehér betűt** kért.
2. **A színeken csak apró finomításokat szabad csinálni**, egyszerre keveset.
   Nem szereti, ha egyszerre sokat változik a kinézet.
3. DN (DOS Navigator) esztétika: single-line border, egér + billentyű
   navigáció.
4. A TUI nem jeleníti meg jól a széles dobozrajzoló karakteres táblázatokat
   (╔═╗║╚╝ — üres sorok közéjük). **Egyszerű ASCII:** `=` fejléc, `-`
   elválasztó, sima felsorolás. 55 karakternél szélesebb dobozokat kerülni.

## Billentyűzet

5. **A teljes kilépés CSAK a Hermes fő nézetéből van (F10).** F10 kontextusfüggő:
   fájlkezelőben → vissza a Hermes-be (dnPanel: false), belső szerkesztőben →
   vissza a fájlkezelőbe, nyitott menüből → menü bezárás. Ctrl+C csak másolás
   (ha van kijelölés) és interrupt (ha AI válaszol) — SOHA ne törölje a beviteli
   mezőt, ne lépjen ki. Ctrl+D se.
6. F1-F10 funkcióbillentyűk a menüsor alatt — **3 rétegű alsó gombsor**
   (a FunctionKeyBar a réteg szerint vált): Hermes fő nézet (F1 Súgó,
   F2 Model, F3 Cron, F4 Skills, F5 Session, F6 Plugins, F7 Tools, F8 Email,
   F9 AIMP, F10 Kilépés), DN fájlkezelő (F3 Nézet, F4 Szerkeszt, F5 Másolás,
   F6 Áthelyez, F7 Új mappa, F8 Törlés, F10 = Hermes), belső szerkesztő
   (F2-F9 kódolásváltók, F10 = Vissza). A fő nézet F2-F7 kezelése a
   useInputHandlers.ts-ben van, dnPanel/dnInternal kizárással (a fájlkezelő
   és a belső szerkesztő saját F-gombjai ne ütközzenek); a belső szerkesztőben
   a globális kezelésből csak a Ctrl+C interrupt marad.

## Viselkedés

7. **Ne változtass konfigot, szolgáltatást vagy menüt a user kérése nélkül.**
   Minden változtatás előtt: (1) nézd meg a jelenlegi állapotot, (2) nézz
   utána, hogy a megoldás működik-e itt, (3) változtatás után teszteld.
8. A menük magyarul legyenek (kivéve a stock Hermes parancsneveket, mint
   New session, Exit).
9. Ha új menüpont kell: a meglévő szerkezetbe illeszkedjen (lásd
   02_menu_bekotes.md), ne legyen külön út.

## Kommunikáció

10. Rövid, tömör válaszok. Ha működik: "typecheck + build + teszt zöld" —
    ennyi, nem kell magyarázkodás. Nincs nyelvkeverék (magyar válasz).
11. A hibáknál komponens-szintű magyarázat: melyik komponens melyik API-t
    hívja, mit kap, miért bukik.
