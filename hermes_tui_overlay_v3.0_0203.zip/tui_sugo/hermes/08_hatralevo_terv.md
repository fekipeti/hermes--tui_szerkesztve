# 08 — Hátralévő fejlesztési terv (a 24 pont + a kisablakos chat)

Ez a fájl a **TUI-fork hátralévő fejlesztési munkáját** rögzíti, ahogy azt
Péter és az agent a beszélgetésekben megtervezte. Források:
`munkai\md\hermes\hermes tui\dn_terv_2026-08-02.md`,
`dn_menuk_2026-08-06.md`, `kisablakos_chat_terv_2026-08-09.md`.

Zsákmány-kérdésre gyors válasz: **a 24 pontból 10 kész + a 25., hátra 14,
köztük a 6-os "mindenképp" listából már csak a Flat nézet van hátra.**

---

## 1. A 24 pont (a DN-fájlkezelő bővítése) — állapot

A lista a dn_menuk "KIEGÉSZÍTETT ÁTEMELÉSI LISTA" (10-es top + 14 új) alapján.
Jelölés: ✅ kész (melyik kör) · 🔲 hátra.

| # | Pont | Állapot |
|---|------|---------|
| 1 | Quick dirs (gyors könyvtárak) — kedvenc mappák, egy gombos ugrás | 🔲 hátra |
| 2 | Sort by (rendezés: név/méret/dátum + fejléc-kattintás irányváltás) | ✅ KÉSZ (9. kör 2026-08-11, 14bdb7de) |
| 3 | Compare directories (két panel eltérései) | 🔲 hátra |
| 4 | Könyvtár-előzmények (Alt+←/→ vissza/előre, panelonként) | ✅ KÉSZ (9. kör, 14bdb7de) |
| 5 | Find / keresés (Alt-F7) a könyvtárban | 🔲 hátra |
| 6 | Csoport-kijelölés (Shift+↑/↓, Ins, Ctrl+A, Select group maszk) | ✅ KÉSZ (5. kör 2026-08-08, 0427ff28) |
| 7 | "Mindig ezzel" editor (az F3/F4 választó memóriája, dn.default_editor) | 🔲 hátra |
| 8 | Calculator / Calendar / ASCII tábla | 🔲 hátra |
| 9 | Fájlszűrő (Advanced filter, pl. *.txt) a panelben | 🔲 hátra |
| 10 | Panel elrejtés (Ctrl+F1/F2/P, egyik panel kicsinyítése) | 🔲 hátra |
| 11 | Encoding — kódolásváltás a belső nézőben/szerkesztőben | ✅ KÉSZ (9. kör 2026-08-12, 508fcf8a) |
| 12 | Csoportos átnevezés (Ctrl+M) — dialógus 2 móddal (maszk helyben / F6 a másik panelre) | ✅ KÉSZ (5. kör, 0427ff28) |
| 13 | Hash / ellenőrző fájl (SHA256 + vágólapra) | ✅ KÉSZ (5. kör, infó-panel [Hash] gomb) |
| 14 | Nevek vágólapra (Manager → Vágólapra ▸, 3 sor) | ✅ KÉSZ (5. kör, 0427ff28) |
| 15 | Hálózat (WSL a Change drive-ban + SFTP + letöltés/feltöltés) | ✅ KÉSZ (8. kör 2026-08-08, 361ad744 → d9ec9bef) |
| 16 | **Flat nézet (Ctrl+B)** — minden almappa fájlja egy listában | 🔲 **hátra — a 6-ból az egyetlen!** |
| 17 | Mappaszinkronizálás (két mappa eltérései + szinkron) | 🔲 hátra |
| 18 | Fájl összehasonlítás / diff (két fájl tartalma) | 🔲 hátra |
| 19 | Becsomagolás/Kicsomagolás (Alt+F5/F9, 7z/tar motor + archívum-teszt) | 🔲 hátra |
| 20 | Kijelölés mentése/visszaállítása (listába) | 🔲 hátra |
| 21 | Chmod / Link / Symlink (Linux jogok és linkek, WSL) | 🔲 hátra |
| 22 | Gyorsfeljegyzés a fájlhoz (Ctrl+Z, a Desc oszlophoz) | 🔲 hátra |
| 23 | Fájlkódolás (MIME/base64) — kódolás/dekódolás | 🔲 hátra |
| 24 | VFS — belépés az archívumba mappaként (a zip belülről böngészhető) | 🔲 hátra |
| 25 | Új fájl (File menü → txt/md/lnk/üres, csák DN módban) | ✅ KÉSZ (6. kör 2026-08-08, ea2138c8) |

**Kész:** 2, 4, 6, 11, 12, 13, 14, 15, 25  ← 9 pont + a 25.
**Hátra:** 1, 3, 5, 7, 8, 9, 10, 16, 17, 18, 19, 20, 21, 22, 23, 24  ← 16 pont.

### A 6 pontos "mindenképp" lista (Péter kedvencei)

1. ~~Encoding~~ KÉSZ · 2. ~~Csoportos átnevezés~~ KÉSZ · 3. ~~Hash~~ KÉSZ ·
4. ~~Nevek vágólapra~~ KÉSZ · 5. ~~Hálózat~~ KÉSZ · **6. Flat nézet — HÁTRA**
(az egyetlen a 6-ból).

### Értelmes fejlesztési sorrend (a hátralévőkből)

1. **Flat nézet (16)** — a 6-os kedvenc, egy gomb (Ctrl+B), Left/Right → Nézet
2. **Quick dirs (1)** + **Find (5)** — a napi fájlkezelés leghasznosabbjai
3. **"Mindig ezzel" editor (7)** — a dn.default_editor configba
4. **Fájlszűrő (9)** + **Panel elrejtés (10)** — apró, de sűrűn használt
5. **Compare (3)** + **diff (18)** + **Mappaszinkron (17)** — a párhuzamos panelek ereje
6. **Calc/Calendar/ASCII (8), VFS (24), Becsomagolás (19), Kijelölés-mentés (20),
   Chmod/Link (21), Gyorsfeljegyzés (22), Fájlkódolás (23)** — a hosszú távú vég

---

## 2. Kisablakos chat (kisablakos_chat_terv_2026-08-09) — TERV, nem kész

**Koncepció (Péter ötlete):** a TUI mellé egy KÜLÖN, kis ablak, ami CSAK a
chatet mutatja — hogy ne a félképernyős TUI-t bambulja, miközben az agent
(computer use) a háttérben dolgozik.

- KÜLÖN ablak (NEM a terminál kicsinyítése, NEM a TUI része)
- Méret: kb. a GitHub Copilot chatablaka — keskeny, oldalsó panel
- CSAK a user ↔ LLM párbeszéd; a munka (fájlkezelő, menük) a TUI-ban marad
- **Adatáramlás a két ablak közt (megoldandó):** a TUI egy chat-logot/naplót
  ír (fájl vagy socket), a kisablak azt olvassa és mutatja — szinkronban
- Minden mást a computer use-zal az agent lát

**Kérdések (nyitott):** technológia (mini Electron/WebView, második Windows
Terminal, a hermes-webui nézete?), indítás (TUI menüpont?), a chat-log formátuma
(a hermes-sessionök már mentődnek).

**Állapot:** 2026-08-14-ig **NEM készült el** — csak terv a
`munkai\md\hermes\hermes tui\kisablakos_chat_terv_2026-08-09.md`-ban.

## 3. Computer use stabilitása (a terv 3. pontja)

- A cua-driver lefagyott / unreachable lett ("3 egymást követő hiba után"),
  egyes weboldalaknál beragadt (2026-08-09)
- **RÉSZBEN MEGOLDVA:** 2026-08-09 frissítés 0.12.6 → **0.19.2**, a
  `cua_backend.py` auto-revive (session idle-TTL után azonos id-vel újraindít)
  a forkban + a pendrive-csomagban
- Hátra: a `hermes computer-use doctor` kimenetének vizsgálata, alternatív
  vezérlési út (böngésző CDP), timeout/retry finomhangolás

## 4. Kutatás: a nagy cégek computer use megoldásai (a terv 4. pontja)

Megnézni, milyen nagy cégek csináltak computer use klónokat / hasonlót —
tanulni, összehasonlítani a cua-driverrel, esetleg stabilabbra váltani.

- OpenAI — Operator (böngésző-agent) · Anthropic — Computer Use (Claude API)
- Google — Project Mariner / Gemini · Microsoft — OmniParser / UFO
- Nyílt: browser-use, Stagehand, UI-TARS, Playwright MCP

**Állapot:** kutatási jegyzet még nincs elkészítve (nyitott).

---

## Források és hivatkozások

- `munkai\md\hermes\hermes tui\dn_terv_2026-08-02.md` — az F3/F4/FP alapok
- `munkai\md\hermes\hermes tui\dn_menuk_2026-08-06.md` — a döntések háza,
  a 24 pont felbontásban, körönként (6-9. kör részletei)
- `munkai\md\hermes\hermes tui\kisablakos_chat_terv_2026-08-09.md` — a
  kisablakos chat + computer use + kutatás terv

*Frissítve: 2026-08-14 (a pendrive2 tui_sugo pontosításakor).*
